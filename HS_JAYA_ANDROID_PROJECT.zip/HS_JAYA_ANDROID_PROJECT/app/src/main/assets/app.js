/* HS JAYA's interface is bundled with the APK; all BLE I/O goes through HsNative. */
(function () {
  'use strict';
  const storeKey = 'hs-jaya-ui-v1';
  const defaults = {hue:0,rgb:[255,255,255],brightness:50,speed:75,remBrightness:75,remSpeed:60,channel:4,power:true,pixel:120,delay:2,quick:[null,null,null,null,null,null],modes:{welcome:4,standby:4,sein:4,rem:4,mundur:4,mode210:4},localPassword:''};
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(storeKey) || '{}') || {}; } catch (_) { /* private storage may be unavailable */ }
  const state = Object.assign({}, defaults, saved);
  state.modes = Object.assign({}, defaults.modes, saved.modes || {});
  state.quick = Array.isArray(saved.quick) ? saved.quick.slice(0,6) : defaults.quick.slice();
  while (state.quick.length < 6) state.quick.push(null);
  if(!Array.isArray(state.rgb)||state.rgb.length!==3)state.rgb=null;
  const content = document.getElementById('content');
  const drawer = document.getElementById('drawer');
  const backdrop = document.getElementById('drawer-backdrop');
  const toastBox = document.getElementById('toast');
  const nav = document.getElementById('navigation');
  const settingsShortcut = document.getElementById('settings-shortcut');
  let page = 'home', ready = false, status = 'Belum terhubung', toastTimer, rulerTimer, lastSliderAt = 0, wheelLastAt = 0, wheelStart = null, dialStart = null;
  const channelCodes = [1,2,4,5,3];
  const colors = ['#ff278e','#22d8fa','#2ee735','#ffc325','#bd55ff'];
  const presets = ['#ff172e','#17e340','#128eff','#ffffff','#ff9617','#f028ce'];
  const items = [
    ['home','Beranda','⌂'],['welcome','Mode Welcome','✧'],['standby','Mode Standby','◉'],
    ['sein','Mode Sein','↗'],['rem','Mode Rem','⏸'],['mundur','Mode Mundur','↶'],
    ['auto','Auto Mode Custom','∞'],['mode210','210 Mode','◌'],['settings','Pengaturan','⚙']
  ];
  const specs = {
    welcome:{title:'WELCOME',min:0,max:50,cmd:0x18,all:true,pixel:true},
    standby:{title:'STANDBY',min:0,max:10,local:true,pixel:true},
    sein:{title:'SEIN',min:0,max:10,cmd:0x19,all:true,palette:true},
    rem:{title:'REM',min:0,max:10,cmd:0x1A,all:true,palette:true},
    mundur:{title:'MUNDUR',min:0,max:10,local:true,palette:true},
    mode210:{title:'210 MODE',min:1,max:210,cmd:0x03,pixel:true}
  };

  function clamp(v,lo,hi){return Math.min(hi,Math.max(lo,Number(v)||0));}
  function persist(){try{localStorage.setItem(storeKey,JSON.stringify(state));}catch(_) { /* UI still works */ }}
  function flash(message){toastBox.textContent=message;toastBox.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastBox.classList.remove('show'),2700);}
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function send(method,...args){
    if(!ready){flash('Sambungkan modul LED melalui tombol koneksi dulu');return false;}
    try {window.HsNative[method](...args);return true;} catch (_) {flash('Koneksi aplikasi belum tersedia');return false;}
  }
  function updateConnection(){
    const target=document.getElementById('connection');
    target.innerHTML='<button type="button" class="connect-button '+(ready?'ready':'')+'" id="connect" aria-label="'+(ready?'Putuskan koneksi':'Cari dan hubungkan modul LED')+'">'+escapeHtml(status)+(ready?' · Putus':' · Hubungkan')+'</button>';
    document.querySelectorAll('[data-ble-status]').forEach(el=>el.textContent=status);
    document.querySelectorAll('[data-device-action]').forEach(el=>el.textContent=ready?'PUTUSKAN KONEKSI':'CARI & HUBUNGKAN');
    document.querySelectorAll('[data-ble-dot]').forEach(el=>el.classList.toggle('connected',ready));
  }
  window.hsBleStatus=function(text,isReady){status=String(text);ready=!!isReady;updateConnection();};
  function setDrawer(open){drawer.classList.toggle('open',open);drawer.setAttribute('aria-hidden',String(!open));backdrop.hidden=!open;}
  function renderLinks(){document.getElementById('drawer-links').innerHTML=items.map(([id,label,icon])=>'<a href="#'+id+'" data-page="'+id+'" class="'+(page===id?'active':'')+'">'+icon+' &nbsp;'+label+'</a>').join('');}
  function navigate(next){if(!['home','settings','device','auto','bahasa','password','about','privacy','wallpaper'].includes(next)&&!specs[next])return;page=next;setDrawer(false);render();window.scrollTo(0,0);}
  window.hsGoBack=function(){if(drawer.classList.contains('open'))setDrawer(false);else if(page==='home')flash('Gunakan tombol kembali sekali lagi untuk keluar');else navigate(['device','bahasa','password','about','privacy','wallpaper'].includes(page)?'settings':'home');};
  function heading(word){return '<h1 class="page-title"><span class="rainbow">MODE</span> '+word+'</h1><p class="eyebrow">HS JAYA LIGHTING · Hybrid Innovation</p>';}
  function slider(which,label,icon,val,pink=false){return '<div class="slider-row '+(pink?'pink':'')+'"><span class="slider-icon" aria-hidden="true">'+icon+'</span><div class="slider-main"><label for="'+which+'">'+label+' <output id="'+which+'-value">'+val+'%</output></label><input id="'+which+'" type="range" min="1" max="100" value="'+val+'" data-slider="'+which+'" aria-label="'+label+'"></div><span class="slider-end" aria-hidden="true">'+(pink?'♧':'☼')+'</span></div>';}
  function channelPicks(){return '<div class="channel-row" aria-label="Pilih kanal">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((x,i)=>'<button class="channel-pick '+(state.channel===i?'active':'')+'" data-channel="'+i+'" type="button">'+x+'</button>').join('')+'</div>';}
  function rgbForHue(h){
    const n=((360-Math.round(h))%360+360)%360;
    const f=(k)=>{let x=(k+n/60)%6;return Math.round(255*(1-Math.max(0,Math.min(x,4-x,1))));};
    return [f(5),f(3),f(1)];
  }
  function currentRgb(){return state.rgb||rgbForHue(state.hue);}
  function currentHex(){return '#'+currentRgb().map(x=>x.toString(16).padStart(2,'0')).join('');}
  function flame(){return '<svg class="flame-art" viewBox="0 0 82 100" aria-hidden="true"><path d="M42 1C45 18 34 24 32 35c-2 8 5 13 7 17-13-4-15-11-16-21C16 41 17 49 18 56 8 60 5 70 8 79c6 17 21 21 34 21 17 0 32-9 34-27 1-12-7-23-16-28 0 12-5 14-9 16 7-20-7-31-9-60Z" fill="currentColor" opacity=".85"/><path d="M40 37c3 9-3 15-8 22-6 7-9 13-7 20 1 10 8 16 18 17 9 0 18-7 19-17 2-8-3-13-7-18-2 10-7 11-11 12 3-10-3-19-4-36Z" fill="white" opacity=".78"/><path d="M40 65c1 7-8 11-8 18 0 7 4 11 10 11 7 0 12-6 11-12-1-4-4-7-6-9 0 5-2 8-5 8 2-8-2-12-2-16Z" fill="currentColor"/></svg>';}
  function home(){
    let rgb=currentRgb();
    return '<div class="home-stage"><div class="hue-shell"><div class="hue-wheel" id="hue-wheel" role="slider" aria-label="Roda pilih warna" aria-valuemin="0" aria-valuemax="359" aria-valuenow="'+state.hue+'" tabindex="0"><div class="hue-handle" id="hue-handle"></div><div class="hue-center">⌖</div></div></div><div class="home-side"><button type="button" class="power '+(state.power?'on':'')+'" id="power" aria-label="Lampu '+(state.power?'mati':'nyala')+'"><svg class="power-glyph" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 5v18"/><path d="M13.2 12.2a17 17 0 1 0 21.6 0"/></svg></button><div class="rgb-readout">'+rgb.map((v,i)=>'<div class="rgb-line"><b>'+['R','G','B'][i]+'</b><output id="rgb-'+i+'">'+v+'</output></div>').join('')+'</div><div class="mini-hue" aria-hidden="true"></div></div></div>'+ 
      '<section class="glass sliders">'+slider('brightness','BRIGHTNESS','☼',state.brightness)+slider('speed','SPEED','◉',state.speed,true)+'</section>'+
      '<section class="glass panel"><p class="section-label">PRESET COLOR</p><div class="preset-grid">'+presets.map((c,i)=>'<button type="button" class="preset" data-preset="'+i+'" style="--flame:'+c+'" aria-label="Pilih warna '+(i+1)+'">'+flame()+'</button>').join('')+'</div></section>'+
      '<section class="glass panel"><p class="section-label">QUICK SAVE</p><div class="save-grid">'+state.quick.map((v,i)=>'<button type="button" data-quick="'+i+'" class="save-slot '+(v?'saved':'')+'" style="--saved:'+(v||'transparent')+'" aria-label="'+(v?'Gunakan':'Simpan')+' warna '+(i+1)+'">'+(v?'●':'+')+'</button>').join('')+'</div><p class="tiny-hint">Ketuk + untuk menyimpan warna ini. Tekan lama warna tersimpan untuk mengganti.</p></section>';
  }
  function modeCards(spec){let which=spec.all?4:state.channel;return '<div class="mode-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((label,i)=>'<button type="button" class="mode-card '+(which===i?'active':'')+'" data-mode-channel="'+i+'" style="--card-color:'+colors[i]+'"><strong>'+label+'</strong><span class="dot"></span><small>MODE</small><b>'+state.modes[page]+'</b></button>').join('')+'</div>';}
  function modeTicks(spec){let html='';for(let value=spec.min;value<=spec.max;value++){let hue=((value-spec.min)*31)%360;html+='<button type="button" class="mode-tick '+(value===state.modes[page]?'selected':'')+'" data-mode-value="'+value+'" style="--tick-color:hsl('+hue+' 95% 67%)">'+(value===0&&(page==='sein'||page==='rem')?'STOP':value)+'</button>';}return html;}
  function modeView(spec){
    let value=clamp(state.modes[page],spec.min,spec.max);state.modes[page]=value;
    let info=spec.local?'<div class="glass notice"><strong>Belum didukung firmware ini.</strong> Pilihan '+spec.title+' hanya disimpan di ponsel; MCU tidak menerima perintah mode '+spec.title+'.</div>':(spec.all?'<div class="glass notice">Mode '+spec.title+' dari firmware berlaku untuk semua LED. Geser lingkaran atau angka untuk memilih.'+(page==='sein'||page==='rem'?' Pilih STOP untuk menghentikan preview.':' Welcome tersedia dari 0 sampai 50.')+'</div>':'<div class="glass notice">Pilih LED 1–4 atau ALL sebelum menggeser. Mode 1–210 dikirim sesuai kanal pilihan.</div>');
    let pixel=spec.pixel?'<section class="glass panel"><p class="panel-title">SETTING PIXEL</p><div class="setting-input"><input type="number" id="pixel" min="1" max="1000" inputmode="numeric" value="'+state.pixel+'" aria-label="Jumlah LED 1 sampai 1000"><button type="button" data-action="pixel">ATUR</button></div><p class="muted">Jumlah LED untuk modul, berlaku di semua halaman.</p></section>':'';
    let palette=spec.palette?'<section class="glass panel"><p class="section-label">WARNA CEPAT</p><div class="swatches">'+presets.map((c,i)=>'<button type="button" class="swatch" data-preset="'+i+'" style="--swatch:'+c+'" aria-label="Warna '+(i+1)+'"></button>').join('')+'</div><p class="tiny-hint">Warna RGB mengganti mode aktif pada kanal yang dipilih.</p></section>':'';
    let brightness=page==='rem'?state.remBrightness:state.brightness,speed=page==='rem'?state.remSpeed:state.speed;
    return heading(spec.title)+modeCards(spec)+'<section class="glass dial-panel"><p class="section-label">PILIH MODE</p><div class="dial-visual" id="dial" aria-label="Geser lingkaran untuk mengganti mode"><div class="dial-core"><output id="dial-number">'+value+'</output><small>GESER MODE</small></div></div><div class="dial-orbit"></div><div class="ruler-shell"><div class="mode-ruler" id="mode-ruler" aria-label="Daftar mode yang dapat digeser">'+modeTicks(spec)+'</div></div><p class="dial-instruction">Geser ke kiri atau kanan untuk memilih mode</p></section>'+pixel+palette+
      '<div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',speed)+'</section></div>'+info+'<button type="button" class="save-action" data-action="mode-save">▣ &nbsp;'+(spec.local?'SIMPAN DI PONSEL':'SIMPAN')+'</button>';
  }
  function autoView(){return heading('AUTO')+'<p class="page-intro">Mode otomatis firmware; pilihan jeda disimpan untuk tampilan aplikasi.</p><div class="mode-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((v,i)=>'<div class="mode-card" style="--card-color:'+colors[i]+'"><strong>'+v+'</strong><span class="dot"></span><small>MODE</small><b>AUTO</b></div>').join('')+'</div><section class="glass panel"><p class="panel-title">AUTO MODE CUSTOM</p><p class="muted">Perintah AUTO menjalankan urutan bawaan firmware (03 FF). Pengaturan waktu custom belum tersedia pada firmware ini.</p><div class="delay-list">'+[0,1,2,3,5].map(v=>'<button type="button" data-delay="'+v+'" class="'+(state.delay===v?'active':'')+'">'+v+' dtk</button>').join('')+'</div><p class="tiny-hint">Jeda di atas adalah catatan lokal; MCU tetap memakai jeda bawaan.</p></section><div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',state.brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',state.speed)+'</section></div><button class="save-action" data-action="auto-save" type="button">▣ &nbsp;AKTIFKAN AUTO</button>';
  }
  function menuIcon(kind){
    const paths={
      bluetooth:'<path d="M12 2v20l6-5-6-5 6-5-6-5ZM6 6l12 11M6 18 18 7"/>',
      welcome:'<path d="M8 14V6a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v7l.8-.8a2 2 0 0 1 3 2.5l-5.5 7a5 5 0 0 1-4 1.8h-3a5 5 0 0 1-3.9-2l-4.5-6a2 2 0 0 1 3-2.5L8 14Z" transform="translate(1 -1) scale(.8)"/>',
      standby:'<path d="M19.4 17.7A9 9 0 0 1 6.3 4.6 9 9 0 1 0 19.4 17.7Z"/><path d="m16 4 1 2 2 .3-1.6 1.4.4 2.1M20 2l.5 1 1.2.2-.9.9.2 1"/>',
      sein:'<path d="M3 12h18M3 12l5-5M3 12l5 5m13-5-5-5m5 5-5 5"/>',
      rem:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="6"/><path d="M12 7v6m0 3v.5"/>',
      mundur:'<path d="M6 18V6h4a3 3 0 0 1 0 6H6m4 0 3 6m5-9v9m-3-3 3 3 3-3"/>',
      auto:'<path d="M4 19 12 4l8 15M7 14h10"/>',
      about:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.5"/>',
      privacy:'<path d="M12 2 4 5v6c0 5 3.4 8.6 8 11 4.6-2.4 8-6 8-11V5l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
      password:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
      wallpaper:'<rect x="3" y="4" width="18" height="16" rx="1"/><circle cx="16" cy="8" r="1"/><path d="m4 17 5-5 4 4 2-2 5 4"/>',
      bahasa:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18m0-18c5 5 5 13 0 18M5 7h14M5 17h14"/>',
      mode210:'<circle cx="12" cy="12" r="9"/><path d="M5 12h14M12 5v14"/>'
    };
    return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths[kind]+'</svg>';
  }
  function menuRow(target,title,description,icon,color,extra){return '<button class="menu-row" type="button" data-page="'+target+'"><span class="menu-icon '+color+'">'+menuIcon(icon)+'</span><span class="menu-copy"><strong>'+title+'</strong><small>'+description+'</small></span>'+(extra?'<span class="menu-extra">'+extra+'</span>':'')+'<span class="menu-arrow" aria-hidden="true">›</span></button>';}
  function settings(){return '<div class="settings-screen"><section class="settings-device">'+menuRow('device','DEVICE & CONNECTION','Kelola perangkat dan koneksi','bluetooth','cyan','HS JAYA LIGHTING')+'</section><h2 class="settings-section-title">SETTINGS</h2><section class="menu-group">'+[
      ['welcome','MODE WELLCOME','Atur efek saat aplikasi pertama kali dibuka','welcome','violet'],
      ['standby','MODE STANDBY','Atur efek saat LED dalam keadaan on/standby','standby','green'],
      ['sein','MODE SEIN','Atur efek lampu sein kiri dan kanan','sein','yellow'],
      ['rem','MODE REM','Atur efek saat lampu rem aktif','rem','red'],
      ['mundur','MODE MUNDUR','Atur efek saat gigi mundur aktif','mundur','blue'],
      ['auto','AUTO MODE CUSTOM','Atur efek otomatis sesuai keinginan','auto','yellow']
    ].map(x=>menuRow(...x)).join('')+'</section><h2 class="settings-section-title">ABOUT</h2><section class="menu-group compact">'+menuRow('about','ABOUT RGB HYBRID','Informasi aplikasi','about','cyan')+menuRow('privacy','PRIVACY POLICY','Kebijakan privasi','privacy','violet')+'</section><h2 class="settings-section-title">OTHER</h2><section class="menu-group compact">'+menuRow('password','PASSWORD','Atur atau ubah password aplikasi','password','violet')+menuRow('wallpaper','WALLPAPER','Pilih wallpaper aplikasi','wallpaper','pink')+menuRow('bahasa','BAHASA','Pilih bahasa aplikasi','bahasa','cyan')+'</section><h2 class="settings-section-title">KONTROL TAMBAHAN</h2><section class="menu-group compact">'+menuRow('mode210','210 MODE','Pilih mode firmware 1–210','mode210','blue')+'</section><p class="settings-fineprint">RGB HYBRID · HS JAYA LIGHTING</p></div>';}
  function deviceView(){return '<div class="device-screen"><h1 class="page-title">DEVICE & CONNECTION</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass device-card"><div class="device-head"><span class="menu-icon cyan">'+menuIcon('bluetooth')+'</span><div><strong>LEDCAR-02-9931</strong><p>BLE · FFE0 / FFE1</p></div><span data-ble-dot class="ble-dot '+(ready?'connected':'')+'"></span></div><p class="device-status" data-ble-status>'+escapeHtml(status)+'</p><button type="button" class="device-connect" data-action="connect" data-device-action>'+(ready?'PUTUSKAN KONEKSI':'CARI & HUBUNGKAN')+'</button></section><section class="glass panel device-help"><h2>Cara menghubungkan</h2><p>Nyalakan modul, tutup aplikasi LEDCAR lama jika masih terhubung, lalu ketuk CARI & HUBUNGKAN. Izinkan akses Perangkat di sekitar dan Lokasi; hidupkan layanan Lokasi di ponsel bila hasil scan kosong.</p><p>Saat nama <strong>LEDCAR-02-9931</strong> muncul, ketuk perangkat itu. Ikon ★ menandai perangkat yang sesuai firmware. Jika gagal, matikan dan nyalakan Bluetooth serta modul, lalu coba Scan ulang.</p><p>Firmware saat kontak fisik/PIN7 LOW hanya menerima perintah Welcome.</p></section></div>';}
  function simplePage(title,body){return '<h1 class="page-title">'+title+'</h1><p class="eyebrow">RGB HYBRID · HS JAYA LIGHTING</p><section class="glass panel"><p class="muted">'+body+'</p></section>';}
  function password(){return '<h1 class="page-title">KUNCI MODUL</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><p class="panel-title">Kontrol penguncian MCU</p><p class="muted">Mengirim perintah kunci firmware. Ini bukan kata sandi untuk membuka aplikasi.</p><button class="pill danger" type="button" data-action="lock">Kunci modul</button><button class="pill" type="button" data-action="unlock">Buka kunci</button></section><div class="glass notice">Layar kata sandi dan timer otomatis pada gambar referensi belum didukung firmware yang dipakai. Tidak ada kata sandi yang disimpan di aplikasi.</div>';}
  function bahasa(){return '<h1 class="page-title">BAHASA</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><button class="language-choice selected" type="button">◉ &nbsp; Bahasa Indonesia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; English · belum tersedia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; 中文 · belum tersedia</button></section>';}
  function render(){
    nav.textContent=page==='home'?'☰':'←';nav.setAttribute('aria-label',page==='home'?'Buka menu':'Kembali');
    document.body.classList.toggle('home-page',page==='home');
    document.body.classList.toggle('settings-page',page==='settings');
    settingsShortcut.style.visibility=['settings','device'].includes(page)?'hidden':'visible';
    content.innerHTML=page==='home'?home():specs[page]?modeView(specs[page]):page==='auto'?autoView():page==='settings'?settings():page==='device'?deviceView():page==='password'?password():page==='bahasa'?bahasa():page==='about'?simplePage('ABOUT RGB HYBRID','Aplikasi HS JAYA untuk mengontrol modul LEDCAR-02-9931 dengan koneksi Bluetooth BLE. Versi 1.1.0.'):page==='privacy'?simplePage('PRIVACY POLICY','Aplikasi bekerja secara lokal lewat Bluetooth. Teks kebijakan privasi resmi belum tersedia.'):simplePage('WALLPAPER','Pilihan wallpaper khusus belum tersedia dalam versi ini.');
    renderLinks();updateConnection();
    if(page==='home')updateWheel();
    if(specs[page]){let ruler=document.getElementById('mode-ruler');requestAnimationFrame(()=>{if(ruler&&document.getElementById('mode-ruler')===ruler)ruler.scrollLeft=(state.modes[page]-specs[page].min)*58;});}
  }
  function updateWheel(){
    const dot=document.getElementById('hue-handle'),wheel=document.getElementById('hue-wheel');if(!dot||!wheel)return;
    const angle=-state.hue*Math.PI/180;
    dot.style.left=(50+49*Math.cos(angle))+'%';dot.style.top=(50+49*Math.sin(angle))+'%';wheel.setAttribute('aria-valuenow',String(state.hue));
    currentRgb().forEach((v,i)=>{let el=document.getElementById('rgb-'+i);if(el)el.textContent=String(v);});
  }
  function chooseHue(h,transmit){state.hue=((Math.round(h)%360)+360)%360;state.rgb=rgbForHue(state.hue);persist();updateWheel();if(transmit)send('rgb',...state.rgb,channelCodes[page==='home'?4:state.channel]);}
  function choosePreset(index){const hex=presets[index];state.rgb=hex.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));persist();if(page==='home')updateWheel();send('rgb',...state.rgb,channelCodes[page==='home'?4:state.channel]);}
  function modeValue(v,transmit){let spec=specs[page];if(!spec)return;v=clamp(v,spec.min,spec.max);if(state.modes[page]===v)return;state.modes[page]=v;persist();let output=document.getElementById('dial-number');if(output)output.textContent=v;
    document.querySelectorAll('.mode-tick').forEach(t=>t.classList.toggle('selected',Number(t.dataset.modeValue)===v));document.querySelectorAll('.mode-card b').forEach(t=>t.textContent=v);
    if(transmit&&!spec.local)send('send',spec.cmd,v,spec.all?3:channelCodes[state.channel]);
  }
  function scrollRuler(v,behavior){const el=document.getElementById('mode-ruler');if(el&&specs[page])el.scrollTo({left:(v-specs[page].min)*58,behavior:behavior||'smooth'});}
  function sliderInput(el,final){let name=el.dataset.slider,val=clamp(el.value,1,100),rem=page==='rem';let key=rem?(name==='brightness'?'remBrightness':'remSpeed'):name;state[key]=val;persist();let output=document.getElementById(name+'-value');if(output)output.textContent=val+'%';if(specs[page]&&specs[page].local)return;
    if(final||Date.now()-lastSliderAt>170){lastSliderAt=Date.now();if(rem)send('remSetting',name==='brightness'?1:2,val);else send('send',name==='brightness'?1:2,val,3);}
  }
  function wheelPointer(ev){let box=ev.currentTarget.getBoundingClientRect(),dx=ev.clientX-(box.left+box.width/2),dy=ev.clientY-(box.top+box.height/2);return (360-Math.atan2(dy,dx)*180/Math.PI)%360;}
  content.addEventListener('pointerdown',ev=>{const wheel=ev.target.closest('#hue-wheel'),dial=ev.target.closest('#dial'),quick=ev.target.closest('[data-quick]');if(wheel){wheelStart=wheel;wheel.setPointerCapture(ev.pointerId);chooseHue(wheelPointer(ev),false);ev.preventDefault();}if(dial){dialStart={x:ev.clientX,v:state.modes[page]};dial.setPointerCapture(ev.pointerId);}if(quick){quick.dataset.held='0';quick._long=setTimeout(()=>{quick.dataset.held='1';const i=Number(quick.dataset.quick);state.quick[i]=currentHex();persist();render();flash('Warna tersimpan diperbarui');},650);}});
  content.addEventListener('pointermove',ev=>{if(wheelStart&&ev.target.closest('#hue-wheel')){chooseHue(wheelPointer(ev),Date.now()-wheelLastAt>125);wheelLastAt=Date.now();}if(dialStart){let diff=dialStart.x-ev.clientX;if(Math.abs(diff)>12)modeValue(dialStart.v+Math.round(diff/30),false);}});
  content.addEventListener('pointerup',ev=>{if(wheelStart){chooseHue(wheelPointer(ev),true);wheelStart=null;}if(dialStart){let selected=state.modes[page];dialStart=null;scrollRuler(selected,'smooth');if(specs[page]&&!specs[page].local)send('send',specs[page].cmd,selected,specs[page].all?3:channelCodes[state.channel]);}let quick=ev.target.closest('[data-quick]');if(quick)clearTimeout(quick._long);});
  content.addEventListener('pointercancel',()=>{wheelStart=null;dialStart=null;});
  content.addEventListener('scroll',ev=>{if(ev.target.id!=='mode-ruler'||!specs[page])return;let selected=clamp(Math.round(ev.target.scrollLeft/58)+specs[page].min,specs[page].min,specs[page].max);if(state.modes[page]===selected)return;modeValue(selected,false);clearTimeout(rulerTimer);rulerTimer=setTimeout(()=>{if(specs[page]&&!specs[page].local)send('send',specs[page].cmd,selected,specs[page].all?3:channelCodes[state.channel]);},180);},true);
  content.addEventListener('input',ev=>{if(ev.target.matches('[data-slider]'))sliderInput(ev.target,false);});
  content.addEventListener('change',ev=>{if(ev.target.matches('[data-slider]'))sliderInput(ev.target,true);});
  content.addEventListener('keydown',ev=>{if(ev.target.id==='hue-wheel'){if(ev.key==='ArrowLeft'||ev.key==='ArrowRight'){chooseHue(state.hue+(ev.key==='ArrowRight'?3:-3),true);ev.preventDefault();}}});
  content.addEventListener('click',ev=>{
    const target=ev.target.closest('button');if(!target)return;
    if(target.dataset.page){navigate(target.dataset.page);return;}
    if(target.dataset.channel!==undefined){state.channel=Number(target.dataset.channel);persist();render();return;}
    if(target.dataset.modeChannel!==undefined){let i=Number(target.dataset.modeChannel);if(specs[page]&&specs[page].all){flash('Firmware mengatur mode ini untuk semua LED');return;}state.channel=i;persist();render();return;}
    if(target.dataset.modeValue!==undefined){const v=Number(target.dataset.modeValue);modeValue(v,true);scrollRuler(v,'smooth');return;}
    if(target.dataset.preset!==undefined){choosePreset(Number(target.dataset.preset));return;}
    if(target.dataset.quick!==undefined){if(target.dataset.held==='1'){target.dataset.held='0';return;}let i=Number(target.dataset.quick),v=state.quick[i];if(!v){state.quick[i]=currentHex();persist();render();flash('Warna disimpan di slot '+(i+1));}else{state.rgb=v.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));persist();updateWheel();send('rgb',...state.rgb,3);flash('Warna slot '+(i+1)+' digunakan');}return;}
    if(target.dataset.delay!==undefined){state.delay=Number(target.dataset.delay);persist();render();return;}
    if(target.dataset.area!==undefined){if(send('subareaDouble',Number(target.dataset.area)))flash('Subarea '+target.dataset.area+' dikirim');return;}
    if(target.id==='power'){let next=!state.power;if(!send('send',4,next?1:0,3))return;state.power=next;persist();target.classList.toggle('on',state.power);target.setAttribute('aria-label','Lampu '+(state.power?'mati':'nyala'));return;}
    switch(target.dataset.action){
      case 'connect': if(!window.HsNative){flash('Bluetooth tersedia di APK Android');break;}ready?window.HsNative.disconnect():window.HsNative.connect();break;
      case 'pixel':{let field=document.getElementById('pixel');let val=clamp(field.value,1,1000);field.value=val;state.pixel=val;persist();if(send('pixel',val))flash('Jumlah LED '+val+' dikirim');break;}
      case 'mode-save':{let spec=specs[page];persist();if(spec.local){flash('Pilihan disimpan di ponsel; firmware belum mendukung');break;}if(send('send',spec.cmd,state.modes[page],spec.all?3:channelCodes[state.channel]))flash('Mode '+state.modes[page]+' dikirim ke MCU');break;}
      case 'auto-save':if(send('send',3,255,3))flash('AUTO bawaan MCU diaktifkan');break;
      case 'lock':if(send('send',22,1,3))flash('Kunci modul dikirim');break;
      case 'unlock':if(send('send',22,0,3))flash('Buka kunci modul dikirim');break;
      case 'ota':if(window.HsNative)window.HsNative.ota();else flash('Tautan OTA tersedia di APK');break;
    }
  });
  document.getElementById('drawer-links').addEventListener('click',ev=>{let link=ev.target.closest('[data-page]');if(link){ev.preventDefault();navigate(link.dataset.page);}});
  document.getElementById('drawer-close').addEventListener('click',()=>setDrawer(false));backdrop.addEventListener('click',()=>setDrawer(false));
  nav.addEventListener('click',()=>page==='home'?navigate('settings'):window.hsGoBack());settingsShortcut.addEventListener('click',()=>navigate('settings'));
  document.getElementById('connection').addEventListener('click',ev=>{if(!ev.target.closest('#connect'))return;if(!window.HsNative){flash('Bluetooth hanya tersedia dalam APK Android');return;}ready?window.HsNative.disconnect():window.HsNative.connect();});
  render();
})();
