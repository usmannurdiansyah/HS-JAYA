
(function(){
'use strict';
const stage=document.getElementById('stage'), viewport=document.getElementById('viewport');
const toast=document.getElementById('toast'), drawer=document.getElementById('drawer'), backdrop=document.getElementById('drawerBackdrop');
const storeKey='hs-jaya-full-v1';
const channelCodes=[1,2,4,5,3];
const colors=['#ff168d','#18dff8','#23e139','#ffd227','#be57ff'];
const presets=[[255,23,46],[23,227,64],[18,142,255],[255,255,255],[255,150,23],[240,40,206]];
const specs={
  welcome:{min:0,max:50,cmd:0x18,global:true,pixel:true},
  standby:{min:0,max:10,local:true,pixel:true},
  sein:{min:0,max:10,cmd:0x19,global:true,palette:true},
  rem:{min:0,max:10,cmd:0x1A,global:true,palette:true,remSettings:true},
  mundur:{min:0,max:10,local:true,palette:true},
  mode210:{min:1,max:210,cmd:0x03,perChannel:true,pixel:true}
};
const pageAssets={
  welcome:{header:'img/welcome_header.jpg',cards:'img/welcome_cards.jpg',mid:'img/welcome_mid.jpg',sliders:'img/welcome_sliders.jpg',save:'img/welcome_save.jpg'},
  standby:{header:'img/standby_header.jpg',cards:'img/standby_cards.jpg',mid:'img/standby_mid.jpg',sliders:'img/standby_sliders.jpg',save:'img/standby_save.jpg'},
  sein:{header:'img/sein_header.jpg',cards:'img/sein_cards.jpg',mid:'img/sein_palette_or_mid.jpg',sliders:'img/sein_sliders.jpg',save:'img/sein_save.jpg'},
  rem:{header:'img/sein_header.jpg',cards:'img/sein_cards.jpg',mid:'img/sein_palette_or_mid.jpg',sliders:'img/sein_sliders.jpg',save:'img/sein_save.jpg'},
  mundur:{header:'img/mundur_header.jpg',cards:'img/mundur_cards.jpg',mid:'img/mundur_palette.jpg',sliders:'img/mundur_sliders.jpg',save:'img/mundur_save.jpg'},
  mode210:{header:'img/mode210_header.jpg',cards:'img/cards_common.jpg',mid:'img/pixel_common.jpg',sliders:'img/sliders_common.jpg',save:'img/save_common.jpg'}
};
const defaults={
 page:'home',selected:4,enabled:[true,true,true,true],power:true,
 brightness:75,speed:60,remBrightness:75,remSpeed:60,pixel:120,delay:2,
 hue:0,rgb:[255,255,255],quick:[null,null,null,null,null,null],
 mode:{
  welcome:[0,3,4,2],standby:[0,3,4,2],sein:[0,3,4,2],
  rem:[0,3,4,2],mundur:[0,3,4,2],mode210:[33,34,36,39]
 },
 baseType:['rgb','rgb','rgb','rgb'],
 baseRgb:[[255,255,255],[255,255,255],[255,255,255],[255,255,255]],
 base210:[33,34,36,39]
};
let saved={};try{saved=JSON.parse(localStorage.getItem(storeKey)||'{}')||{}}catch(_){}
const state=Object.assign({},defaults,saved);
state.enabled=Array.isArray(saved.enabled)&&saved.enabled.length===4?saved.enabled.slice():defaults.enabled.slice();
state.quick=Array.isArray(saved.quick)?saved.quick.slice(0,6):defaults.quick.slice();
while(state.quick.length<6)state.quick.push(null);
state.mode=Object.assign({},defaults.mode,saved.mode||{});
Object.keys(defaults.mode).forEach(k=>{if(!Array.isArray(state.mode[k])||state.mode[k].length!==4)state.mode[k]=defaults.mode[k].slice()});
state.baseType=Array.isArray(saved.baseType)&&saved.baseType.length===4?saved.baseType.slice():defaults.baseType.slice();
state.baseRgb=Array.isArray(saved.baseRgb)&&saved.baseRgb.length===4?saved.baseRgb.map(x=>Array.isArray(x)?x.slice(0,3):[255,255,255]):defaults.baseRgb.map(x=>x.slice());
state.base210=Array.isArray(saved.base210)&&saved.base210.length===4?saved.base210.slice():defaults.base210.slice();
let ready=false,status='Belum terhubung',toastTimer=null,drawerOpen=false,lastSliderAt=0,pendingQuick=null;

function clamp(v,a,b){return Math.min(b,Math.max(a,Number(v)||0))}
function persist(){try{localStorage.setItem(storeKey,JSON.stringify(state))}catch(_){}}
function say(t){toast.textContent=t;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),1800)}
function fit(){const vv=window.visualViewport,w=Math.max(240,vv?vv.width:document.documentElement.clientWidth),sc=w/282;stage.style.transform=`scale(${sc})`;requestAnimationFrame(()=>viewport.style.height=(stage.scrollHeight*sc)+'px')}
addEventListener('resize',fit,{passive:true});if(window.visualViewport)visualViewport.addEventListener('resize',fit,{passive:true});
const scaleNow=()=>stage.getBoundingClientRect().width/282;
function native(method,...args){
 if(!ready){say('Hubungkan modul LED dulu');return false}
 try{if(!window.HsNative||typeof window.HsNative[method]!=='function')throw 0;window.HsNative[method](...args);return true}catch(_){say('Bridge Android belum tersedia');return false}
}
window.hsBleStatus=function(text,isReady){status=String(text||'');ready=!!isReady;if(state.page==='device')render();};
window.hsGoBack=function(){if(drawerOpen){setDrawer(false);return}if(state.page==='home'){if(window.HsNative&&window.HsNative.exit)window.HsNative.exit();return}go(state.page==='settings'?'home':'settings')};

function setDrawer(open){
 drawerOpen=!!open;drawer.classList.toggle('open',drawerOpen);backdrop.classList.toggle('open',drawerOpen);
 if(drawerOpen)renderDrawer();
}
backdrop.onclick=()=>setDrawer(false);
function renderDrawer(){
 const items=[['home','BERANDA'],['welcome','MODE WELLCOME'],['standby','MODE STANDBY'],['sein','MODE SEIN'],['rem','MODE REM'],['mundur','MODE MUNDUR'],['auto','AUTO MODE CUSTOM'],['mode210','210 MODE'],['settings','PENGATURAN'],['device','DEVICE & CONNECTION'],['password','PASSWORD'],['bahasa','BAHASA']];
 drawer.innerHTML='<button class="close" id="drawerClose">×</button><h2><span>RGB</span> HYBRID</h2><p>HS JAYA LIGHTING · Hybrid Innovation</p>'+items.map(x=>`<button class="menu ${state.page===x[0]?'active':''}" data-go="${x[0]}">${x[1]}</button>`).join('');
 drawer.querySelector('#drawerClose').onclick=()=>setDrawer(false);
 drawer.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{setDrawer(false);go(b.dataset.go)});
}
function go(p){state.page=p;persist();render();scrollTo(0,0)}

function allOn(){return state.enabled.every(Boolean)}
function anyOn(){return state.enabled.some(Boolean)}
function targets(sel=state.selected){return sel===4?[0,1,2,3]:[sel]}
function arr(){return state.mode[state.page]||[4,4,4,4]}
function same(a){return a.every(v=>v===a[0])}
function currentMode(){const a=arr();return state.selected===4?(same(a)?a[0]:a[0]):a[state.selected]}
function spec(){return specs[state.page]}
function label(v){return Number(v)===0?'AUTO':String(v)}
function cardValue(i){const a=arr();if(i<4)return label(a[i]);return same(a)?label(a[0]):'MIX'}
function setModeValue(v){targets().forEach(i=>arr()[i]=v)}
function rememberRgb(rgb,sel=state.selected){targets(sel).forEach(i=>{state.baseType[i]='rgb';state.baseRgb[i]=rgb.slice(0,3)})}
function remember210(v,sel=state.selected){targets(sel).forEach(i=>{state.baseType[i]='mode210';state.base210[i]=v;state.mode.mode210[i]=v})}
function sendRgb(rgb,sel=state.selected){
 const live=targets(sel).filter(i=>state.enabled[i]);if(!live.length){say('Channel yang dipilih OFF');return false}
 if(sel===4&&live.length===4)return native('rgb',rgb[0],rgb[1],rgb[2],3);
 for(const i of live)if(!native('rgb',rgb[0],rgb[1],rgb[2],channelCodes[i]))return false;return true
}
function send210(v,sel=state.selected){
 const live=targets(sel).filter(i=>state.enabled[i]);if(!live.length){say('Channel yang dipilih OFF');return false}
 if(sel===4&&live.length===4)return native('send',0x03,v,3);
 for(const i of live)if(!native('send',0x03,v,channelCodes[i]))return false;return true
}
function sendMode(v){
 const s=spec();if(!s||s.local)return true;
 if(state.page==='mode210')return send210(v);
 if(s.global){const ok=native('send',s.cmd,v,3);if(ok)setTimeout(reapplyOff,190);return ok}
 return native('send',s.cmd,v,3)
}
function restoreChannel(i){
 if(state.baseType[i]==='mode210')return native('send',0x03,state.base210[i],channelCodes[i]);
 const rgb=state.baseRgb[i]||state.rgb;return native('rgb',rgb[0],rgb[1],rgb[2],channelCodes[i])
}
function reapplyOff(){if(!ready)return;const off=[0,1,2,3].filter(i=>!state.enabled[i]);if(off.length===4){native('rgb',0,0,0,3);return}off.forEach(i=>native('rgb',0,0,0,channelCodes[i]))}
function toggleChannel(i){
 if(!ready){say('Hubungkan modul LED dulu');return}
 if(i===4){
   const next=!allOn();
   if(!next){if(!native('rgb',0,0,0,3))return;state.enabled=[false,false,false,false]}
   else{state.enabled=[true,true,true,true];for(let c=0;c<4;c++)restoreChannel(c)}
   persist();renderCardFx();say(next?'Semua LED ON':'Semua LED OFF');return
 }
 const next=!state.enabled[i];
 if(next){state.enabled[i]=true;if(!restoreChannel(i)){state.enabled[i]=false;return}}
 else{if(!native('rgb',0,0,0,channelCodes[i]))return;state.enabled[i]=false}
 persist();renderCardFx();say('LED '+(i+1)+' '+(next?'ON':'OFF'))
}

function seven(v){
 const map={0:'abcdef',1:'bc',2:'abdeg',3:'abcdg',4:'bcfg',5:'acdfg',6:'acdefg',7:'abc',8:'abcdefg',9:'abcdfg'};
 return String(Math.max(0,Math.round(v))).split('').map(ch=>'<span class="digit">'+['a','b','c','d','e','f','g'].map(k=>'<i class="seg '+k+' '+((map[ch]||'').includes(k)?'on':'')+'"></i>').join('')+'</span>').join('')
}

function render(){
 if(specs[state.page])renderMode();
 else if(state.page==='home')renderHome();
 else if(state.page==='settings')renderSettings();
 else if(state.page==='auto')renderAuto();
 else if(state.page==='bahasa'||state.page==='password')renderStaticFull();
 else renderSimple();
 fit()
}

function renderMode(){
 const a=pageAssets[state.page],s=spec();let b=state.page==='rem'?state.remBrightness:state.brightness,sp=state.page==='rem'?state.remSpeed:state.speed;
 stage.innerHTML=`<div class="sec"><img src="${a.header}"><button class="hot back-hot" id="back"></button></div>
 <div class="gap small"></div>
 <div class="sec" id="cards"><img src="${a.cards}">
   ${[0,1,2,3,4].map(i=>`<button class="card-hit c${i}" data-select="${i}"></button><button class="toggle-hit c${i}" data-toggle="${i}"></button>`).join('')}
   <div id="cardFx"></div>
 </div>
 <div class="gap"></div>
 <div class="ring-sec"><img src="img/ring_clean.jpg"><div class="center-cover"></div><div id="bigNumber" class="big-number"></div><div id="labels3d" class="labels3d"></div><div id="ringHit" class="ring-hit"></div></div>
 <div class="gap"></div>
 <div class="sec"><img src="${a.mid}">
   ${s.pixel?`<input id="pixel" class="mid-input" type="number" min="1" max="1000" value="${state.pixel}">`:[0,1,2,3,4,5].map(i=>`<button class="palette-hit p${i}" data-palette="${i}"></button>`).join('')}
 </div>
 <div class="gap small"></div>
 <div class="sec" id="modeSliders"><img src="${a.sliders}"><input id="bright" class="range-hit b" type="range" min="1" max="100" value="${b}"><input id="speed" class="range-hit s" type="range" min="1" max="100" value="${sp}"><div id="sliderFx"></div></div>
 <div class="gap small"></div><div class="sec"><img src="${a.save}"><button id="save" class="save-hit"></button></div><div class="bottom"></div>`;
 document.getElementById('back').onclick=()=>go('settings');
 bindMode();renderCardFx();state.position=currentMode();renderRing();renderModeSliders()
}
function renderCardFx(){
 const host=document.getElementById('cardFx');if(!host)return;host.innerHTML='';
 const sel=document.createElement('i');sel.className='selection c'+state.selected;sel.style.setProperty('--c',colors[state.selected]);host.appendChild(sel);
 for(let i=0;i<5;i++){
   const on=i===4?allOn():state.enabled[i];
   if(!on){
    let m=document.createElement('i');m.className='off-mask c'+i;host.appendChild(m);
    let l=document.createElement('span');l.className='off-label c'+i;l.textContent='OFF';host.appendChild(l);
    let sw=document.createElement('i');sw.className='off-switch c'+i;host.appendChild(sw)
   }
   let mm=document.createElement('i');mm.className='mode-mask c'+i;host.appendChild(mm);
   let mv=document.createElement('b');mv.className='mode-live c'+i;mv.style.setProperty('--c',colors[i]);mv.textContent=cardValue(i);host.appendChild(mv)
 }
}
function renderRing(){
 const host=document.getElementById('labels3d');if(!host)return;const s=spec(),pos=clamp(state.position,s.min,s.max);
 document.getElementById('bigNumber').innerHTML=seven(pos);host.innerHTML='';
 const center=Math.round(pos);
 for(let n=center-7;n<=center+7;n++){
  if(n<s.min||n>s.max)continue;
  const rel=n-pos,theta=rel*19.2*Math.PI/180;if(Math.abs(theta)>1.48)continue;
  const z=Math.cos(theta),x=50+44.5*Math.sin(theta),y=62.5-22*(1-z),edge=Math.min(1,Math.abs(theta)/1.48);
  const sx=1-.42*edge,sy=1-.16*edge,op=Math.max(0,1-.94*Math.pow(edge,1.35)),rotY=-theta*180/Math.PI*.92;
  const hue=((x+6)*3.05)%360,c=Math.abs(rel)<.47?'#fff':`hsl(${hue} 96% 61%)`;
  let t=document.createElement('i');t.className='ring-tick';t.style.left=x+'%';t.style.top=(y-25.5)+'%';t.style.opacity=op;t.style.setProperty('--c',c);t.style.transform=`translate(-50%,-50%) rotate(${(-theta*18)}deg)`;host.appendChild(t);
  let e=document.createElement('b');e.className='ring-label'+(n===0?' auto':'');e.textContent=label(n);e.style.left=(x-6)+'%';e.style.top=(y-21)+'%';e.style.opacity=op;e.style.setProperty('--c',c);e.style.transform=`perspective(180px) rotateY(${rotY}deg) scaleX(${sx}) scaleY(${sy})`;host.appendChild(e)
 }
}
function renderModeSliders(){
 const host=document.getElementById('sliderFx');if(!host)return;host.innerHTML='';
 const vals=[state.page==='rem'?state.remBrightness:state.brightness,state.page==='rem'?state.remSpeed:state.speed];
 [{x0:16,x1:45,y:47,val:vals[0],c:'#ff159e',vx:31},{x0:63,x1:92,y:47,val:vals[1],c:'#2430ff',vx:78}].forEach(o=>{
   let k=document.createElement('i');k.className='slider-knob';k.style.left=(o.x0+(o.x1-o.x0)*o.val/100)+'%';k.style.top=o.y+'%';host.appendChild(k);
   let m=document.createElement('i');m.className='slider-value-mask';m.style.left=(o.vx-7)+'%';m.style.top='55%';m.style.width='14%';m.style.height='25%';host.appendChild(m);
   let v=document.createElement('b');v.className='slider-value';v.style.left=(o.vx-7)+'%';v.style.top='55%';v.style.width='14%';v.style.height='25%';v.style.color=o.c;v.textContent=o.val;host.appendChild(v)
 })
}
function bindMode(){
 document.querySelectorAll('[data-select]').forEach(b=>b.onclick=e=>{e.stopPropagation();state.selected=+b.dataset.select;state.position=currentMode();persist();renderCardFx();renderRing()});
 document.querySelectorAll('[data-toggle]').forEach(b=>{
   b.addEventListener('pointerdown',e=>e.stopPropagation());
   b.onclick=e=>{e.preventDefault();e.stopPropagation();toggleChannel(+b.dataset.toggle)}
 });
 let drag=null,hit=document.getElementById('ringHit');
 hit.onpointerdown=e=>{drag={x:e.clientX,start:state.position};hit.setPointerCapture(e.pointerId);e.preventDefault()};
 hit.onpointermove=e=>{if(!drag)return;const s=spec();state.position=clamp(drag.start+(drag.x-e.clientX)/(25*scaleNow()),s.min,s.max);const v=Math.round(state.position);setModeValue(v);if(state.page==='mode210')remember210(v);renderCardFx();renderRing()};
 const end=()=>{if(!drag)return;state.position=Math.round(state.position);setModeValue(state.position);if(state.page==='mode210')remember210(state.position);persist();renderCardFx();renderRing();sendMode(state.position);say('Mode '+label(state.position));drag=null};
 hit.onpointerup=end;hit.onpointercancel=end;
 const br=document.getElementById('bright'),sp=document.getElementById('speed');
 function slider(name,val,final){
   val=clamp(val,1,100);
   if(state.page==='rem'){if(name==='brightness')state.remBrightness=val;else state.remSpeed=val}else state[name]=val;
   persist();renderModeSliders();
   const now=Date.now();if(!final&&now-lastSliderAt<170)return;lastSliderAt=now;
   if(spec().local)return;
   if(state.page==='rem')native('remSetting',name==='brightness'?1:2,val);
   else native('send',name==='brightness'?1:2,val,3)
 }
 br.oninput=()=>slider('brightness',br.value,false);br.onchange=()=>slider('brightness',br.value,true);
 sp.oninput=()=>slider('speed',sp.value,false);sp.onchange=()=>slider('speed',sp.value,true);
 const px=document.getElementById('pixel');if(px)px.onchange=()=>{state.pixel=clamp(px.value,1,1000);persist();native('pixel',state.pixel);say('Pixel '+state.pixel)};
 document.querySelectorAll('[data-palette]').forEach(p=>p.onclick=()=>{const rgb=presets[+p.dataset.palette];state.rgb=rgb.slice();rememberRgb(rgb);persist();sendRgb(rgb);say('Warna '+(+p.dataset.palette+1))});
 document.getElementById('save').onclick=()=>{persist();if(spec().local)say('Disimpan di aplikasi');else if(sendMode(Math.round(state.position)))say('Pengaturan dikirim')}
}

function renderHome(){
 stage.innerHTML=`<div class="sec home-header"><img src="img/home_header.jpg"><button class="hot menu-hot" id="menuBtn"></button><button class="hot settings-hot" id="gearBtn"></button></div>
 <div class="sec home-wheel"><img src="img/home_wheel.jpg"><button class="hot power-hot" id="powerBtn"></button><div class="hot wheel-hot" id="wheel"></div><i id="homeHandle" class="home-handle"></i></div>
 <div class="sec" id="homeSliders"><img src="img/home_sliders.jpg"><input id="homeBright" class="home-slider b" type="range" min="1" max="100" value="${state.brightness}"><input id="homeSpeed" class="home-slider s" type="range" min="1" max="100" value="${state.speed}"><div id="homeSliderFx"></div></div>
 <div class="sec"><img src="img/home_preset.jpg">${[0,1,2,3,4,5].map(i=>`<button class="preset-hit p${i}" data-preset="${i}"></button>`).join('')}</div>
 <div class="sec" id="quickSec"><img src="img/home_quick.jpg">${[0,1,2,3,4,5].map(i=>`<button class="quick-hit q${i}" data-quick="${i}"></button>`).join('')}<div id="quickFx"></div></div>
 <div class="sec"><img src="img/home_footer.jpg"></div><div class="bottom"></div>`;
 document.getElementById('menuBtn').onclick=()=>setDrawer(true);document.getElementById('gearBtn').onclick=()=>go('settings');
 document.getElementById('powerBtn').onclick=()=>{const next=!state.power;if(native('send',0x04,next?1:0,3)){state.power=next;persist();if(next)setTimeout(reapplyOff,180);say('Lampu '+(next?'ON':'OFF'))}};
 bindHomeWheel();bindHomeSliders();renderQuick()
}
function rgbFromPoint(h,s){
 let c=s,x=c*(1-Math.abs((h/60)%2-1)),m=1-c,r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}
 return [r,g,b].map(n=>Math.round((n+m)*255))
}
function bindHomeWheel(){
 const w=document.getElementById('wheel'),h=document.getElementById('homeHandle');let dragging=false;
 function point(e){const r=w.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,R=Math.min(r.width,r.height)/2,d=Math.min(R,Math.hypot(dx,dy)),a=Math.atan2(dy,dx),px=50+(Math.cos(a)*d/R*50),py=50+(Math.sin(a)*d/R*50),hue=(a*180/Math.PI+360)%360,sat=Math.min(1,d/(R*.94));return {px,py,hue,sat}}
 function apply(e,tx){const p=point(e);h.style.left=(15+p.px*.65)+'%';h.style.top=(9+p.py*.84)+'%';state.hue=p.hue;state.rgb=rgbFromPoint(p.hue,p.sat);rememberRgb(state.rgb);persist();if(tx)sendRgb(state.rgb)}
 w.onpointerdown=e=>{dragging=true;w.setPointerCapture(e.pointerId);apply(e,false);e.preventDefault()};w.onpointermove=e=>{if(dragging)apply(e,false)};w.onpointerup=e=>{if(dragging){apply(e,true);if(pendingQuick!==null){state.quick[pendingQuick]=state.rgb.slice();say('Quick Save '+(pendingQuick+1)+' disimpan');pendingQuick=null;persist();renderQuick()}dragging=false}};w.onpointercancel=()=>dragging=false
}
function bindHomeSliders(){
 const b=document.getElementById('homeBright'),s=document.getElementById('homeSpeed');
 const draw=()=>{const host=document.getElementById('homeSliderFx');host.innerHTML='';[{v:state.brightness,y:34,x0:20,x1:91,c:'#13e4ff'},{v:state.speed,y:73,x0:20,x1:91,c:'#df32f0'}].forEach(o=>{let k=document.createElement('i');k.className='slider-knob';k.style.left=(o.x0+(o.x1-o.x0)*o.v/100)+'%';k.style.top=o.y+'%';host.appendChild(k)})};draw();
 function goSlider(name,val,final){val=clamp(val,1,100);state[name]=val;persist();draw();const now=Date.now();if(!final&&now-lastSliderAt<170)return;lastSliderAt=now;native('send',name==='brightness'?1:2,val,3)}
 b.oninput=()=>goSlider('brightness',b.value,false);b.onchange=()=>goSlider('brightness',b.value,true);s.oninput=()=>goSlider('speed',s.value,false);s.onchange=()=>goSlider('speed',s.value,true);
 document.querySelectorAll('[data-preset]').forEach(x=>x.onclick=()=>{const rgb=presets[+x.dataset.preset];state.rgb=rgb.slice();rememberRgb(rgb);persist();sendRgb(rgb)});
 document.querySelectorAll('[data-quick]').forEach(x=>x.onclick=()=>{const i=+x.dataset.quick;if(!state.quick[i]){pendingQuick=i;say('Pilih warna di lingkaran lalu lepas')}else{state.rgb=state.quick[i].slice();rememberRgb(state.rgb);persist();sendRgb(state.rgb);say('Quick Save '+(i+1))}})
}
function renderQuick(){const host=document.getElementById('quickFx');if(!host)return;host.innerHTML='';state.quick.forEach((rgb,i)=>{if(!rgb)return;let q=document.createElement('i');q.className='quick-color q'+i;q.style.background=`rgb(${rgb.join(',')})`;host.appendChild(q)})}

function renderSettings(){
 stage.innerHTML=`<div class="sec"><img src="img/settings_header.jpg"><button id="settingsBack" class="hot back-hot"></button></div>
 <div class="sec"><img src="img/settings_device.jpg"><button class="settings-hot" style="top:0;height:100%" data-go="device"></button></div>
 <div class="sec" id="settingsMain"><img src="img/settings_main.jpg"></div>
 <div class="sec" id="settingsLower"><img src="img/settings_lower.jpg"></div><div class="bottom"></div>`;
 document.getElementById('settingsBack').onclick=()=>go('home');
 const main=document.getElementById('settingsMain'),lower=document.getElementById('settingsLower');
 [['welcome',0,16.5],['standby',16.5,16.5],['sein',33,16.5],['rem',49.5,16.5],['mundur',66,16.5],['auto',82.5,17.5]].forEach(([p,t,h])=>{let b=document.createElement('button');b.className='settings-hot';b.style.top=t+'%';b.style.height=h+'%';b.onclick=()=>go(p);main.appendChild(b)});
 [['about',0,25],['privacy',25,25],['password',51,16.5],['wallpaper',67.5,16.5],['bahasa',84,16]].forEach(([p,t,h])=>{let b=document.createElement('button');b.className='settings-hot';b.style.top=t+'%';b.style.height=h+'%';b.onclick=()=>go(p);lower.appendChild(b)});
}

function renderAuto(){
 stage.innerHTML=`<div class="sec"><img src="img/auto_header.jpg"><button class="hot back-hot" id="autoBack"></button></div>
 <div class="sec" id="autoCards"><img src="img/auto_cards.jpg">${[0,1,2,3,4,5].map(i=>`<button class="auto-toggle c${i}" data-auto-toggle="${i}"></button>`).join('')}</div>
 <div class="sec"><img src="img/auto_settings.jpg"><input class="auto-range speed" id="autoSpeed" type="range" min="1" max="100" value="${state.speed}"><input class="auto-range brightness" id="autoBright" type="range" min="1" max="100" value="${state.brightness}">${[1,2,3,5].map((v,i)=>`<button class="delay-hit d${i}" data-delay="${v}"></button>`).join('')}</div>
 <div class="sec"><img src="img/auto_info.jpg"></div><div class="sec"><img src="img/auto_save.jpg"><button class="save-hit" id="autoSave"></button></div><div class="bottom"></div>`;
 document.getElementById('autoBack').onclick=()=>go('settings');
 document.querySelectorAll('[data-auto-toggle]').forEach(b=>b.onclick=e=>{e.stopPropagation();const i=+b.dataset.autoToggle;if(i<5)toggleChannel(i);else say('ROLLING mengikuti AUTO firmware')});
 const sp=document.getElementById('autoSpeed'),br=document.getElementById('autoBright');sp.onchange=()=>{state.speed=clamp(sp.value,1,100);persist();native('send',2,state.speed,3)};br.onchange=()=>{state.brightness=clamp(br.value,1,100);persist();native('send',1,state.brightness,3)};
 document.querySelectorAll('[data-delay]').forEach(b=>b.onclick=()=>{state.delay=+b.dataset.delay;persist();say('Jeda '+state.delay+' dtk disimpan di aplikasi')});
 document.getElementById('autoSave').onclick=()=>{if(native('send',3,255,3)){setTimeout(reapplyOff,180);say('AUTO firmware diaktifkan')}}
}

function renderStaticFull(){
 const src=state.page==='bahasa'?'img/bahasa.jpg':'img/password.jpg';
 stage.innerHTML=`<div class="sec"><img src="${src}"><button class="hot" id="staticBack" style="left:1%;top:1%;width:16%;height:11%"></button></div><div class="bottom"></div>`;
 document.getElementById('staticBack').onclick=()=>go('settings')
}

function renderSimple(){
 const titles={device:'DEVICE & CONNECTION',about:'ABOUT RGB HYBRID',privacy:'PRIVACY POLICY',wallpaper:'WALLPAPER'};
 const title=titles[state.page]||state.page.toUpperCase();
 let body='';
 if(state.page==='device')body=`<div class="simple-card"><h3><span class="status-dot ${ready?'ready':''}"></span>${status}</h3><p>Target BLE: LEDCAR-02-9931 · Service FFE0 · Characteristic FFE1.</p><button class="action" id="connectBtn">${ready?'PUTUSKAN':'CARI & HUBUNGKAN'}</button><button class="action" id="otaBtn">UPDATE OTA</button></div>`;
 else if(state.page==='about')body='<div class="simple-card"><h3>HS JAYA LIGHTING</h3><p>RGB HYBRID controller untuk modul LEDCAR/ESP32 4 channel.</p></div>';
 else if(state.page==='privacy')body='<div class="simple-card"><h3>PRIVACY</h3><p>Kontrol LED bekerja lokal melalui Bluetooth. Aplikasi tidak memerlukan akun untuk mengontrol modul.</p></div>';
 else body='<div class="simple-card"><h3>WALLPAPER</h3><p>Halaman wallpaper tersedia. Penggantian wallpaper tidak mengubah protokol firmware.</p></div>';
 stage.innerHTML=`<div class="simple-page"><div class="simple-head"><button class="simple-back" id="simpleBack">←</button><h1 class="simple-title">${title}</h1></div>${body}</div>`;
 document.getElementById('simpleBack').onclick=()=>go('settings');
 if(state.page==='device'){document.getElementById('connectBtn').onclick=()=>{if(!window.HsNative){say('Bluetooth tersedia di APK Android');return}ready?window.HsNative.disconnect():window.HsNative.connect()};document.getElementById('otaBtn').onclick=()=>{if(window.HsNative&&window.HsNative.ota)window.HsNative.ota()}}
}
render();setTimeout(fit,50);
})();
