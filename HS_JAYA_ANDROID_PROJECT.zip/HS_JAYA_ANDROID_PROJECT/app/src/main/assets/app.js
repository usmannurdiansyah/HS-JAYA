/* HS JAYA's interface is bundled with the APK; all BLE I/O goes through HsNative. */
(function () {
  'use strict';
  const storeKey = 'hs-jaya-ui-v1';
  const defaults = {hue:0,rgb:[255,255,255],brightness:50,speed:75,remBrightness:75,remSpeed:60,channel:4,power:true,pixel:120,delay:2,quick:[null,null,null,null,null,null],modes:{welcome:4,standby:4,sein:4,rem:4,mundur:4,mode210:4},channelEnabled:[true,true,true,true],channelModes:{welcome:[4,4,4,4],standby:[4,4,4,4],sein:[4,4,4,4],rem:[4,4,4,4],mundur:[4,4,4,4],mode210:[4,4,4,4]},channelMode210:[4,4,4,4],channelBaseType:['rgb','rgb','rgb','rgb'],channelBaseRgb:[[255,255,255],[255,255,255],[255,255,255],[255,255,255]],localPassword:''};
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(storeKey) || '{}') || {}; } catch (_) { /* private storage may be unavailable */ }
  const state = Object.assign({}, defaults, saved);
  state.modes = Object.assign({}, defaults.modes, saved.modes || {});
  state.quick = Array.isArray(saved.quick) ? saved.quick.slice(0,6) : defaults.quick.slice();
  while (state.quick.length < 6) state.quick.push(null);
  if(!Array.isArray(state.rgb)||state.rgb.length!==3)state.rgb=null;
  if(!Array.isArray(state.channelEnabled)||state.channelEnabled.length!==4)state.channelEnabled=defaults.channelEnabled.slice();
  state.channelEnabled=state.channelEnabled.map(v=>v!==false);
  if(!Array.isArray(state.channelMode210)||state.channelMode210.length!==4)state.channelMode210=[0,1,2,3].map(()=>clamp(state.modes.mode210||4,1,210));
  state.channelMode210=state.channelMode210.map(v=>clamp(v,1,210));
  if(!state.channelModes||typeof state.channelModes!=='object')state.channelModes={};
  ['welcome','standby','sein','rem','mundur','mode210'].forEach(id=>{
    const specDefaults={welcome:[4,4,4,4],standby:[4,4,4,4],sein:[4,4,4,4],rem:[4,4,4,4],mundur:[4,4,4,4],mode210:state.channelMode210.slice()};
    let arr=Array.isArray(state.channelModes[id])&&state.channelModes[id].length===4?state.channelModes[id].slice():specDefaults[id].slice();
    const lo=id==='mode210'?1:0,hi=id==='mode210'?210:(id==='welcome'?50:10),fallback=clamp(state.modes[id]||4,lo,hi);
    arr=arr.map(v=>clamp(v,lo,hi));
    if(!saved.channelModes||!Array.isArray(saved.channelModes[id])){
      if(id==='mode210'&&Array.isArray(saved.channelMode210)&&saved.channelMode210.length===4)arr=state.channelMode210.slice();
      else arr=[fallback,fallback,fallback,fallback];
    }
    state.channelModes[id]=arr;
  });
  state.channelMode210=state.channelModes.mode210.slice();
  if(!Array.isArray(state.channelBaseType)||state.channelBaseType.length!==4)state.channelBaseType=defaults.channelBaseType.slice();
  if(!Array.isArray(state.channelBaseRgb)||state.channelBaseRgb.length!==4)state.channelBaseRgb=[0,1,2,3].map(()=>[255,255,255]);
  state.channelBaseRgb=state.channelBaseRgb.map(v=>Array.isArray(v)&&v.length===3?v.map(x=>clamp(x,0,255)):[255,255,255]);
  const content = document.getElementById('content');
  const drawer = document.getElementById('drawer');
  const backdrop = document.getElementById('drawer-backdrop');
  const toastBox = document.getElementById('toast');
  const nav = document.getElementById('navigation');
  const settingsShortcut = document.getElementById('settings-shortcut');
  const brandEl = document.querySelector('.brand');
  let page = 'home', ready = false, status = 'Belum terhubung', toastTimer, rulerTimer, lastSliderAt = 0, wheelLastAt = 0, wheelStart = null, dialStart = null, pendingQuickSlot = null;
  const channelCodes = [1,2,4,5,3];
  const colors = ['#ff278e','#22d8fa','#2ee735','#ffc325','#bd55ff'];
  const presets = ['#ff172e','#17e340','#128eff','#ffffff','#ff9617','#f028ce'];
  const items = [
    ['home','Beranda','⌂'],['welcome','Mode Welcome','✧'],['standby','Mode Standby','◉'],
    ['sein','Mode Sein','↗'],['rem','Mode Rem','⏸'],['mundur','Mode Mundur','↶'],
    ['auto','Auto Mode Custom','∞'],['mode210','210 Mode','◌'],['settings','Pengaturan','⚙']
  ];
  const specs = {
    welcome:{title:'WELCOME',min:0,max:50,cmd:0x18,firmwareGlobal:true,pixel:true},
    standby:{title:'STANDBY',min:0,max:10,local:true,pixel:true},
    sein:{title:'SEIN',min:0,max:10,cmd:0x19,firmwareGlobal:true,palette:true},
    rem:{title:'REM',min:0,max:10,cmd:0x1A,firmwareGlobal:true,palette:true},
    mundur:{title:'MUNDUR',min:0,max:10,local:true,palette:true},
    mode210:{title:'210 MODE',min:1,max:210,cmd:0x03,pixel:true,perChannel:true}
  };

  function clamp(v,lo,hi){return Math.min(hi,Math.max(lo,Number(v)||0));}
  function persist(){try{localStorage.setItem(storeKey,JSON.stringify(state));}catch(_) { /* UI still works */ }}
  function flash(message){toastBox.textContent=message;toastBox.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastBox.classList.remove('show'),2700);}
  function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function send(method,...args){
    if(!ready){flash('Sambungkan modul LED melalui tombol koneksi dulu');return false;}
    try {window.HsNative[method](...args);return true;} catch (_) {flash('Koneksi aplikasi belum tersedia');return false;}
  }
  function updateConnection(){
    const target=document.getElementById('connection');
    target.innerHTML='<button type="button" class="connect-button '+(ready?'ready':'')+'" id="connect" aria-label="'+(ready?'Putuskan koneksi':'Cari dan hubungkan modul LED')+'">'+escapeHtml(status)+(ready?' · Putus':' · Hubungkan')+'</button>';
    document.querySelectorAll('[data-ble-status]').forEach(el=>el.textContent=status);
    document.querySelectorAll('[data-device-action]').forEach(el=>el.textContent=ready?'PUTUSKAN KONEKSI':'CARI & HUBUNGKAN');
    document.querySelectorAll('[data-ble-dot]').forEach(el=>el.classList.toggle('connected',ready));
  }
  window.hsBleStatus=function(text,isReady){
    const wasReady=ready;status=String(text);ready=!!isReady;updateConnection();
    if(ready&&!wasReady)setTimeout(reapplySoftOffState,280);
  };
  function setDrawer(open){drawer.classList.toggle('open',open);drawer.setAttribute('aria-hidden',String(!open));backdrop.hidden=!open;}
  function renderLinks(){document.getElementById('drawer-links').innerHTML=items.map(([id,label,icon])=>'<a href="#'+id+'" data-page="'+id+'" class="'+(page===id?'active':'')+'">'+icon+' &nbsp;'+label+'</a>').join('');}
  function navigate(next){if(!['home','settings','device','auto','bahasa','password','about','privacy','wallpaper'].includes(next)&&!specs[next])return;page=next;setDrawer(false);render();window.scrollTo(0,0);}
  window.hsGoBack=function(){if(drawer.classList.contains('open'))setDrawer(false);else if(page==='home')flash('Gunakan tombol kembali sekali lagi untuk keluar');else navigate(['device','bahasa','password','about','privacy','wallpaper'].includes(page)?'settings':'home');};
  function heading(word){return '<div class="mode-sub-brand"><span class="mini-brand-mark">H</span><span><b>HS JAYA LIGHTING</b><small>Hybrid Innovation</small></span></div>'; }
  function slider(which,label,icon,val,pink=false){return '<div class="slider-row '+(pink?'pink':'')+'"><span class="slider-icon" aria-hidden="true">'+icon+'</span><div class="slider-main"><label for="'+which+'">'+label+' <output id="'+which+'-value">'+val+'%</output></label><input id="'+which+'" type="range" min="1" max="100" value="'+val+'" data-slider="'+which+'" aria-label="'+label+'"></div><span class="slider-end" aria-hidden="true">'+(pink?'♧':'☼')+'</span></div>';}
  function channelPicks(){return '<div class="channel-row" aria-label="Pilih kanal warna dasar">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((x,i)=>{let on=i===4?state.channelEnabled.some(Boolean):state.channelEnabled[i];return '<button class="channel-pick '+(state.channel===i?'active ':'')+(on?'channel-on':'channel-off')+'" data-channel="'+i+'" type="button"><span>'+x+'</span><i aria-hidden="true"></i></button>';}).join('')+'</div>';}
  function targetChannels(selection){return selection===4?[0,1,2,3]:[clamp(selection,0,3)];}
  function allChannelsOn(){return state.channelEnabled.every(Boolean);}
  function anyChannelsOn(){return state.channelEnabled.some(Boolean);}
  function pageModeArray(id){
    if(!state.channelModes[id])state.channelModes[id]=[state.modes[id],state.modes[id],state.modes[id],state.modes[id]];
    return state.channelModes[id];
  }
  function selectedModeValue(id,selection){
    const arr=pageModeArray(id),pick=selection===undefined?state.channel:selection;
    if(pick<4)return arr[pick];
    const first=arr[0];return arr.every(v=>v===first)?first:state.modes[id];
  }
  function setSelectedModeValue(id,value,selection){
    const arr=pageModeArray(id),pick=selection===undefined?state.channel:selection;
    targetChannels(pick).forEach(i=>arr[i]=value);
    state.modes[id]=value;
    if(id==='mode210')state.channelMode210=arr.slice();
  }
  function cardModeValue(i){
    const arr=pageModeArray(page);
    if(i<4)return arr[i];
    const first=arr[0];return arr.every(v=>v===first)?first:'MIX';
  }
  function rememberRgb(rgb,selection){targetChannels(selection).forEach(i=>{state.channelBaseType[i]='rgb';state.channelBaseRgb[i]=rgb.slice(0,3);});}
  function rememberMode210(value,selection){targetChannels(selection).forEach(i=>{state.channelBaseType[i]='mode210';state.channelMode210[i]=value;state.channelModes.mode210[i]=value;});state.modes.mode210=value;}
  function sendRgbSelection(rgb,selection){
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    if(selection===4&&live.length===4)return send('rgb',rgb[0],rgb[1],rgb[2],3);
    for(const i of live)if(!send('rgb',rgb[0],rgb[1],rgb[2],channelCodes[i]))return false;
    return true;
  }
  function sendMode210Selection(value,selection){
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    if(selection===4&&live.length===4)return send('send',0x03,value,3);
    for(const i of live)if(!send('send',0x03,value,channelCodes[i]))return false;
    return true;
  }
  function sendPageModeSelection(value,selection){
    const spec=specs[page];if(!spec||spec.local)return true;
    if(page==='mode210')return sendMode210Selection(value,selection);
    // Firmware saat ini membaca Welcome/Sein/Rem sebagai menu global. UI tetap menyimpan
    // angka per LED agar kartu/scroll independen, tetapi paket BLE mengikuti firmware asli.
    if(spec.firmwareGlobal){const ok=send('send',spec.cmd,value,3);if(ok)scheduleSoftOffReapply();return ok;}
    const live=targetChannels(selection).filter(i=>state.channelEnabled[i]);
    if(!live.length){flash('Channel yang dipilih sedang OFF');return false;}
    if(selection===4&&live.length===4)return send('send',spec.cmd,value,3);
    for(const i of live)if(!send('send',spec.cmd,value,channelCodes[i]))return false;
    return true;
  }
  function restoreChannel(i){
    if(state.channelBaseType[i]==='mode210')return send('send',0x03,state.channelMode210[i],channelCodes[i]);
    const rgb=state.channelBaseRgb[i]||currentRgb();return send('rgb',rgb[0],rgb[1],rgb[2],channelCodes[i]);
  }
  function reapplySoftOffState(){
    if(!ready)return;
    const off=[0,1,2,3].filter(i=>!state.channelEnabled[i]);
    if(off.length===4){send('rgb',0,0,0,3);return;}
    off.forEach(i=>send('rgb',0,0,0,channelCodes[i]));
  }
  function scheduleSoftOffReapply(){if(state.channelEnabled.some(v=>!v))setTimeout(reapplySoftOffState,180);}
  function refreshChannelVisuals(){
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>{
      const i=Number(card.dataset.modeCardChannel),on=i===4?allChannelsOn():state.channelEnabled[i],mixed=i===4&&anyChannelsOn()&&!allChannelsOn();
      card.classList.toggle('channel-on',on);card.classList.toggle('channel-off',!on&&!mixed);card.classList.toggle('channel-mixed',mixed);
      const toggle=card.querySelector('[data-channel-toggle]');if(toggle){toggle.classList.toggle('on',on);toggle.classList.toggle('mixed',mixed);toggle.setAttribute('aria-pressed',String(on));const em=toggle.querySelector('em');if(em)em.textContent=mixed?'MIX':(on?'ON':'OFF');}
    });
    document.querySelectorAll('.channel-pick').forEach(btn=>{const i=Number(btn.dataset.channel),on=i===4?anyChannelsOn():state.channelEnabled[i];btn.classList.toggle('channel-on',on);btn.classList.toggle('channel-off',!on);btn.classList.toggle('active',state.channel===i);});
  }
  function toggleSoftChannel(index){
    const connected=ready;
    if(index===4){
      const next=!allChannelsOn();
      if(!next){
        if(connected)send('rgb',0,0,0,3);
        state.channelEnabled=[false,false,false,false];
      }else{
        state.channelEnabled=[true,true,true,true];
        if(connected)for(let i=0;i<4;i++)restoreChannel(i);
      }
      persist();refreshChannelVisuals();refreshRefVisuals();
      flash(next?'Semua LED ON':'Semua LED OFF');
      return;
    }
    const next=!state.channelEnabled[index];
    state.channelEnabled[index]=next;
    if(connected){
      if(next)restoreChannel(index);
      else send('rgb',0,0,0,channelCodes[index]);
    }
    persist();refreshChannelVisuals();refreshRefVisuals();
    flash('LED '+(index+1)+' '+(next?'ON':'OFF'));
  }
  function selectChannel(index){state.channel=clamp(index,0,4);persist();document.querySelectorAll('[data-channel]').forEach(btn=>btn.classList.toggle('active',Number(btn.dataset.channel)===state.channel));}
  function selectModeChannel(index){
    const spec=specs[page];if(!spec)return;
    state.channel=clamp(index,0,4);
    const v=clamp(selectedModeValue(page,state.channel),spec.min,spec.max);
    if(state.channel<4)state.modes[page]=v;
    persist();
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>card.classList.toggle('active',Number(card.dataset.modeCardChannel)===state.channel));
    const output=document.getElementById('dial-number');if(output)output.innerHTML=sevenSeg(v);
    refreshCurvedTicks();refreshRefVisuals();
    scrollRuler(v,'auto');
  }
  function rgbForHue(h){
    const n=((360-Math.round(h))%360+360)%360;
    const f=(k)=>{let x=(k+n/60)%6;return Math.round(255*(1-Math.max(0,Math.min(x,4-x,1))));};
    return [f(5),f(3),f(1)];
  }
  function currentRgb(){return state.rgb||rgbForHue(state.hue);}
  function currentHex(){return '#'+currentRgb().map(x=>x.toString(16).padStart(2,'0')).join('');}
  function flame(){return '<svg class="flame-art" viewBox="0 0 82 100" aria-hidden="true"><path d="M42 1C45 18 34 24 32 35c-2 8 5 13 7 17-13-4-15-11-16-21C16 41 17 49 18 56 8 60 5 70 8 79c6 17 21 21 34 21 17 0 32-9 34-27 1-12-7-23-16-28 0 12-5 14-9 16 7-20-7-31-9-60Z" fill="currentColor" opacity=".85"/><path d="M40 37c3 9-3 15-8 22-6 7-9 13-7 20 1 10 8 16 18 17 9 0 18-7 19-17 2-8-3-13-7-18-2 10-7 11-11 12 3-10-3-19-4-36Z" fill="white" opacity=".78"/><path d="M40 65c1 7-8 11-8 18 0 7 4 11 10 11 7 0 12-6 11-12-1-4-4-7-6-9 0 5-2 8-5 8 2-8-2-12-2-16Z" fill="currentColor"/></svg>';}
  function home(){
    let rgb=currentRgb();
    return '<div class="home-stage"><div class="hue-shell"><div class="hue-wheel" id="hue-wheel" role="slider" aria-label="Roda pilih warna" aria-valuemin="0" aria-valuemax="359" aria-valuenow="'+state.hue+'" tabindex="0"><div class="hue-center">⌖</div></div></div><div class="home-side"><button type="button" class="power '+(state.power?'on':'')+'" id="power" aria-label="Lampu '+(state.power?'mati':'nyala')+'"><svg class="power-glyph" viewBox="0 0 48 48" aria-hidden="true" focusable="false"><path d="M24 5v18"/><path d="M13.2 12.2a17 17 0 1 0 21.6 0"/></svg></button><div class="rgb-readout">'+rgb.map((v,i)=>'<div class="rgb-line"><b>'+['R','G','B'][i]+'</b><output id="rgb-'+i+'">'+v+'</output></div>').join('')+'</div><div class="mini-hue" aria-hidden="true"></div></div></div>'+channelPicks()+ 
      '<section class="glass sliders">'+slider('brightness','BRIGHTNESS','☼',state.brightness)+slider('speed','SPEED','◉',state.speed,true)+'</section>'+
      '<section class="glass panel"><p class="section-label">PRESET COLOR</p><div class="preset-grid">'+presets.map((c,i)=>'<button type="button" class="preset" data-preset="'+i+'" style="--flame:'+c+'" aria-label="Pilih warna '+(i+1)+'">'+flame()+'</button>').join('')+'</div></section>'+
      '<section class="glass panel"><p class="section-label">QUICK SAVE</p><div class="save-grid">'+state.quick.map((v,i)=>'<button type="button" data-quick="'+i+'" class="save-slot '+(v?'saved':'')+'" style="--saved:'+(v||'transparent')+'" aria-label="'+(v?'Gunakan':'Simpan')+' warna '+(i+1)+'">'+(v?'':'+')+'</button>').join('')+'</div><p class="tiny-hint">Ketuk +, pilih warna di lingkaran, lalu lepas jari untuk menyimpan. Ketuk warna tersimpan untuk memakai.</p></section>';
  }
  function cardStyle(i){
    const fills=['rgba(255,39,142,.48)','rgba(34,216,250,.46)','rgba(46,231,53,.42)','rgba(255,195,37,.44)','rgba(189,85,255,.46)'];
    const glows=['rgba(255,39,142,.72)','rgba(34,216,250,.70)','rgba(46,231,53,.65)','rgba(255,195,37,.68)','rgba(189,85,255,.70)'];
    return '--card-color:'+colors[i]+';--card-fill:'+fills[i]+';--card-glow:'+glows[i];
  }
  function modeCards(spec){
    let which=state.channel;
    return '<div class="mode-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((label,i)=>{
      let on=i===4?allChannelsOn():state.channelEnabled[i],mixed=i===4&&anyChannelsOn()&&!allChannelsOn(),value=cardModeValue(i);
      return '<div class="mode-card '+(which===i?'active ':'')+(on?'channel-on ':'')+(!on&&!mixed?'channel-off ':'')+(mixed?'channel-mixed ':'')+'" data-mode-card-channel="'+i+'" style="'+cardStyle(i)+'"><button type="button" class="mode-card-select" data-mode-channel="'+i+'"><strong>'+label+'</strong><small>MODE</small><b>'+value+'</b></button><button type="button" class="channel-toggle '+(on?'on ':'')+(mixed?'mixed':'')+'" data-channel-toggle="'+i+'" aria-label="'+label+' '+(mixed?'campuran':(on?'ON':'OFF'))+'" aria-pressed="'+on+'"><span aria-hidden="true"></span><em>'+(mixed?'MIX':(on?'ON':'OFF'))+'</em></button></div>';
    }).join('')+'</div>';
  }
  function tickLabel(value){return value===0&&(page==='sein'||page==='rem'||page==='standby'||page==='mundur'||page==='welcome')?'AUTO':String(value);}
  function curvedTicks(spec){
    const selected=clamp(selectedModeValue(page,state.channel),spec.min,spec.max);
    let html='';
    for(let off=-4;off<=4;off++){
      const value=selected+off;if(value<spec.min||value>spec.max)continue;
      let hue=((value-spec.min)*31)%360;
      html+='<button type="button" class="orbit-tick off-'+(off<0?'m'+Math.abs(off):'p'+off)+(off===0?' selected':'')+'" data-mode-value="'+value+'" style="--tick-color:hsl('+hue+' 95% 62%)">'+tickLabel(value)+'</button>';
    }
    return html;
  }
  function refreshCurvedTicks(){const host=document.getElementById('orbit-ticks');if(host&&specs[page])host.innerHTML=curvedTicks(specs[page]);}
  function modeView(spec){
    let raw=selectedModeValue(page,state.channel);let value=clamp(raw,spec.min,spec.max);state.modes[page]=value;if(state.channel<4)pageModeArray(page)[state.channel]=value;if(page==='mode210')state.channelMode210=pageModeArray('mode210').slice();
    let info=spec.local?'<div class="glass notice"><strong>Tampilan independen per LED.</strong> Nilai '+spec.title+' disimpan terpisah LED1–LED4 di aplikasi; firmware saat ini belum punya perintah BLE menu '+spec.title+'.</div>':(spec.firmwareGlobal?'<div class="glass notice">Kartu dan angka LED1–LED4 disimpan independen di aplikasi. Perintah '+spec.title+' tetap dikirim global mengikuti firmware saat ini.</div>':'<div class="glass notice">Pilih LED 1–4 atau ALL sebelum menggeser. Hanya kartu yang dipilih yang berubah; Mode 210 dikirim ke kanal itu.</div>');
    let pixel=spec.pixel?'<section class="glass panel"><p class="panel-title">SETTING PIXEL</p><div class="setting-input"><input type="number" id="pixel" min="1" max="1000" inputmode="numeric" value="'+state.pixel+'" aria-label="Jumlah LED 1 sampai 1000"><button type="button" data-action="pixel">ATUR</button></div><p class="muted">Jumlah LED untuk modul, berlaku di semua halaman.</p></section>':'';
    let palette=spec.palette?'<section class="glass panel"><p class="section-label">WARNA CEPAT</p><div class="swatches">'+presets.map((c,i)=>'<button type="button" class="swatch" data-preset="'+i+'" style="--swatch:'+c+'" aria-label="Warna '+(i+1)+'"></button>').join('')+'</div><p class="tiny-hint">Warna RGB mengganti mode aktif pada kanal yang dipilih.</p></section>':'';
    let brightness=page==='rem'?state.remBrightness:state.brightness,speed=page==='rem'?state.remSpeed:state.speed;
    return heading(spec.title)+modeCards(spec)+'<section class="glass dial-panel neon-mode-panel"><p class="section-label">PILIH MODE</p><div class="holo-selector" id="dial" aria-label="Geser lingkaran untuk mengganti mode"><div class="holo-core"><output id="dial-number">'+value+'</output></div><div class="holo-ring back-ring"></div><div class="holo-ring front-ring"></div><div class="orbit-ticks" id="orbit-ticks">'+curvedTicks(spec)+'</div><div class="center-marker"></div></div><p class="dial-instruction">Geser ke kiri atau kanan untuk memilih mode</p></section>'+pixel+palette+
      '<div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',speed)+'</section></div>'+info+'<button type="button" class="save-action" data-action="mode-save">▣ &nbsp;'+(spec.local?'SIMPAN DI PONSEL':'SIMPAN')+'</button>';
  }
  function autoView(){return heading('AUTO')+'<p class="page-intro">Mode otomatis firmware; pilihan jeda disimpan untuk tampilan aplikasi.</p><div class="mode-cards auto-cards">'+['LED 1','LED 2','LED 3','LED 4','ALL'].map((v,i)=>{let on=i===4?allChannelsOn():state.channelEnabled[i],mixed=i===4&&anyChannelsOn()&&!allChannelsOn();return '<div class="mode-card '+(on?'channel-on ':'')+(!on&&!mixed?'channel-off ':'')+(mixed?'channel-mixed ':'')+'" data-mode-card-channel="'+i+'" style="'+cardStyle(i)+'"><div class="mode-card-select static"><strong>'+v+'</strong><small>MODE</small><b>AUTO</b></div><button type="button" class="channel-toggle '+(on?'on ':'')+(mixed?'mixed':'')+'" data-channel-toggle="'+i+'" aria-label="'+v+' '+(mixed?'campuran':(on?'ON':'OFF'))+'" aria-pressed="'+on+'"><span aria-hidden="true"></span><em>'+(mixed?'MIX':(on?'ON':'OFF'))+'</em></button></div>';}).join('')+'</div><section class="glass panel"><p class="panel-title">AUTO MODE CUSTOM</p><p class="muted">Perintah AUTO menjalankan urutan bawaan firmware (03 FF). Pengaturan waktu custom belum tersedia pada firmware ini.</p><div class="delay-list">'+[0,1,2,3,5].map(v=>'<button type="button" data-delay="'+v+'" class="'+(state.delay===v?'active':'')+'">'+v+' dtk</button>').join('')+'</div><p class="tiny-hint">Jeda di atas adalah catatan lokal; MCU tetap memakai jeda bawaan.</p></section><div class="double-sliders"><section class="glass sliders">'+slider('brightness','KECERAHAN','☼',state.brightness,true)+'</section><section class="glass sliders">'+slider('speed','KECEPATAN','◉',state.speed)+'</section></div><button class="save-action" data-action="auto-save" type="button">▣ &nbsp;AKTIFKAN AUTO</button>';
  }
  function menuIcon(kind){
    const paths={
      bluetooth:'<path d="M12 2v20l6-5-6-5 6-5-6-5ZM6 6l12 11M6 18 18 7"/>',
      welcome:'<path d="M8 14V6a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v7l.8-.8a2 2 0 0 1 3 2.5l-5.5 7a5 5 0 0 1-4 1.8h-3a5 5 0 0 1-3.9-2l-4.5-6a2 2 0 0 1 3-2.5L8 14Z" transform="translate(1 -1) scale(.8)"/>',
      standby:'<path d="M19.4 17.7A9 9 0 0 1 6.3 4.6 9 9 0 1 0 19.4 17.7Z"/><path d="m16 4 1 2 2 .3-1.6 1.4.4 2.1M20 2l.5 1 1.2.2-.9.9.2 1"/>',
      sein:'<path d="M3 12h18M3 12l5-5M3 12l5 5m13-5-5-5m5 5-5 5"/>',
      rem:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="6"/><path d="M12 7v6m0 3v.5"/>',
      mundur:'<path d="M6 18V6h4a3 3 0 0 1 0 6H6m4 0 3 6m5-9v9m-3-3 3 3 3-3"/>',
      auto:'<path d="M4 19 12 4l8 15M7 14h10"/>',
      about:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.5"/>',
      privacy:'<path d="M12 2 4 5v6c0 5 3.4 8.6 8 11 4.6-2.4 8-6 8-11V5l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
      password:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
      wallpaper:'<rect x="3" y="4" width="18" height="16" rx="1"/><circle cx="16" cy="8" r="1"/><path d="m4 17 5-5 4 4 2-2 5 4"/>',
      bahasa:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18m0-18c5 5 5 13 0 18M5 7h14M5 17h14"/>',
      mode210:'<circle cx="12" cy="12" r="9"/><path d="M5 12h14M12 5v14"/>'
    };
    return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+paths[kind]+'</svg>';
  }
  function menuRow(target,title,description,icon,color,extra){return '<button class="menu-row" type="button" data-page="'+target+'"><span class="menu-icon '+color+'">'+menuIcon(icon)+'</span><span class="menu-copy"><strong>'+title+'</strong><small>'+description+'</small></span>'+(extra?'<span class="menu-extra">'+extra+'</span>':'')+'<span class="menu-arrow" aria-hidden="true">›</span></button>';}
  function settings(){return '<div class="settings-screen"><section class="settings-device">'+menuRow('device','DEVICE & CONNECTION','Kelola perangkat dan koneksi','bluetooth','cyan','HS JAYA LIGHTING')+'</section><h2 class="settings-section-title">SETTINGS</h2><section class="menu-group">'+[
      ['welcome','MODE WELLCOME','Atur efek saat aplikasi pertama kali dibuka','welcome','violet'],
      ['standby','MODE STANDBY','Atur efek saat LED dalam keadaan on/standby','standby','green'],
      ['sein','MODE SEIN','Atur efek lampu sein kiri dan kanan','sein','yellow'],
      ['rem','MODE REM','Atur efek saat lampu rem aktif','rem','red'],
      ['mundur','MODE MUNDUR','Atur efek saat gigi mundur aktif','mundur','blue'],
      ['auto','AUTO MODE CUSTOM','Atur efek otomatis sesuai keinginan','auto','yellow']
    ].map(x=>menuRow(...x)).join('')+'</section><h2 class="settings-section-title">ABOUT</h2><section class="menu-group compact">'+menuRow('about','ABOUT RGB HYBRID','Informasi aplikasi','about','cyan')+menuRow('privacy','PRIVACY POLICY','Kebijakan privasi','privacy','violet')+'</section><h2 class="settings-section-title">OTHER</h2><section class="menu-group compact">'+menuRow('password','PASSWORD','Atur atau ubah password aplikasi','password','violet')+menuRow('wallpaper','WALLPAPER','Pilih wallpaper aplikasi','wallpaper','pink')+menuRow('bahasa','BAHASA','Pilih bahasa aplikasi','bahasa','cyan')+'</section><h2 class="settings-section-title">KONTROL TAMBAHAN</h2><section class="menu-group compact">'+menuRow('mode210','210 MODE','Pilih mode firmware 1–210','mode210','blue')+'</section><p class="settings-fineprint">RGB HYBRID · HS JAYA LIGHTING</p></div>';}
  function deviceView(){return '<div class="device-screen"><h1 class="page-title">DEVICE & CONNECTION</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass device-card"><div class="device-head"><span class="menu-icon cyan">'+menuIcon('bluetooth')+'</span><div><strong>LEDCAR-02-9931</strong><p>BLE · FFE0 / FFE1</p></div><span data-ble-dot class="ble-dot '+(ready?'connected':'')+'"></span></div><p class="device-status" data-ble-status>'+escapeHtml(status)+'</p><button type="button" class="device-connect" data-action="connect" data-device-action>'+(ready?'PUTUSKAN KONEKSI':'CARI & HUBUNGKAN')+'</button></section><section class="glass panel device-help"><h2>Cara menghubungkan</h2><p>Nyalakan modul, tutup aplikasi LEDCAR lama jika masih terhubung, lalu ketuk CARI & HUBUNGKAN. Izinkan akses Perangkat di sekitar dan Lokasi; hidupkan layanan Lokasi di ponsel bila hasil scan kosong.</p><p>Saat nama <strong>LEDCAR-02-9931</strong> muncul, ketuk perangkat itu. Ikon ★ menandai perangkat yang sesuai firmware. Jika gagal, matikan dan nyalakan Bluetooth serta modul, lalu coba Scan ulang.</p><p>Firmware saat kontak fisik/PIN7 LOW hanya menerima perintah Welcome.</p></section></div>';}
  function simplePage(title,body){return '<h1 class="page-title">'+title+'</h1><p class="eyebrow">RGB HYBRID · HS JAYA LIGHTING</p><section class="glass panel"><p class="muted">'+body+'</p></section>';}
  function password(){return '<h1 class="page-title">KUNCI MODUL</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><p class="panel-title">Kontrol penguncian MCU</p><p class="muted">Mengirim perintah kunci firmware. Ini bukan kata sandi untuk membuka aplikasi.</p><button class="pill danger" type="button" data-action="lock">Kunci modul</button><button class="pill" type="button" data-action="unlock">Buka kunci</button></section><div class="glass notice">Layar kata sandi dan timer otomatis pada gambar referensi belum didukung firmware yang dipakai. Tidak ada kata sandi yang disimpan di aplikasi.</div>';}
  function bahasa(){return '<h1 class="page-title">BAHASA</h1><p class="eyebrow">HS JAYA LIGHTING</p><section class="glass panel"><button class="language-choice selected" type="button">◉ &nbsp; Bahasa Indonesia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; English · belum tersedia</button><button class="language-choice disabled" type="button" disabled>◯ &nbsp; 中文 · belum tersedia</button></section>';}

  function refImg(name, extra=''){
    const ext=name==='mode210'?'png':'jpg';
    return '<div class="ref-screen ref-'+name+' '+extra+'" style="--ref:url(\'ref/'+name+'.'+ext+'\')"></div>';
  }
  function refHotspot(cls, attrs=''){return '<button type="button" class="ref-hotspot '+cls+'" '+attrs+' aria-label="kontrol"></button>';}
  function sevenSeg(value){
    const chars=String(value).split('');
    const map={0:'abcdef',1:'bc',2:'abdeg',3:'abcdg',4:'bcfg',5:'acdfg',6:'acdefg',7:'abc',8:'abcdefg',9:'abcdfg'};
    return '<span class="seven-wrap">'+chars.map(ch=>'<span class="seven-digit">'+['a','b','c','d','e','f','g'].map(s=>'<i class="seg '+s+' '+((map[ch]||'').includes(s)?'on':'')+'"></i>').join('')+'</span>').join('')+'</span>';
  }
  function refModeOverlay(id){
    const arr=pageModeArray(id), sel=selectedModeValue(id,state.channel), allSame=arr.every(v=>v===arr[0]);
    const vals=[arr[0],arr[1],arr[2],arr[3],allSame?arr[0]:'MIX'];
    let html='<div class="ref-dynamic">';
    vals.forEach((v,i)=>{
      const on=i===4?allChannelsOn():state.channelEnabled[i], mixed=i===4&&anyChannelsOn()&&!allChannelsOn();
      html+='<button class="ref-cardtap c'+i+' '+(state.channel===i?'active-ref ':'')+(!on&&!mixed?'ref-off ':'')+'" data-mode-channel="'+i+'" data-mode-card-channel="'+i+'" type="button" style="'+cardStyle(i)+'"></button>';
      html+='<button class="ref-toggle c'+i+' '+(on?'on ':'')+(mixed?'mixed ':'')+'" data-channel-toggle="'+i+'" type="button" aria-pressed="'+on+'"><span></span></button>';
      html+='<span class="ref-cardval c'+i+'">'+v+'</span>';
    });
    html+='<div class="ref-center-number" id="dial-number">'+sevenSeg(sel)+'</div>';
    html+='<div class="ref-ring-touch" id="dial" aria-label="Geser kiri kanan untuk memilih mode"></div>';
    html+='<div class="ref-live-mode" id="ref-live-mode">'+sel+'</div>';
    html+='</div>';
    return html;
  }
  function modeControls(id){
    const b=id==='rem'?state.remBrightness:state.brightness;
    const s=id==='rem'?state.remSpeed:state.speed;
    let html='<div class="ref-mode-bright"><input type="range" min="1" max="100" value="'+b+'" data-slider="brightness"><output id="brightness-value">'+b+'</output></div>';
    html+='<div class="ref-mode-speed"><input type="range" min="1" max="100" value="'+s+'" data-slider="speed"><output id="speed-value">'+s+'</output></div>';
    if(specs[id]&&specs[id].pixel){
      html+='<div class="ref-pixel"><input id="pixel" type="number" min="1" max="1000" value="'+state.pixel+'"><button type="button" data-action="pixel">ATUR</button></div>';
    }
    if(specs[id]&&specs[id].palette){
      html+='<div class="ref-palette">'+presets.map((c,i)=>'<button type="button" class="rp p'+i+'" data-preset="'+i+'" style="--pc:'+c+'"></button>').join('')+'</div>';
    }
    html+='<button class="ref-mode-save" type="button" data-action="mode-save"></button>';
    return html;
  }
  function refModeView(id){
    let base=id;
    if(id==='rem') base='sein';
    const ext=base==='mode210'?'png':'jpg';
    let overlays=refModeOverlay(id);
    let titlePatch='';
    if(id==='rem') titlePatch='<div class="ref-title-patch"><span class="rainbow">MODE</span> REM</div>';
    return '<div class="ref-page '+id+'"><img class="ref-img" src="ref/'+base+'.'+ext+'" alt="">'+titlePatch+'<button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button>'+overlays+modeControls(id)+'</div>';
  }
  function refAutoView(){
    return '<div class="ref-page auto"><img class="ref-img" src="ref/auto.jpg" alt=""><button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button>'
      +[0,1,2,3,4].map(i=>'<button type="button" class="ref-auto-toggle a'+i+' '+(state.channelEnabled[i]?'on':'off')+'" data-channel-toggle="'+i+'"><span></span></button>').join('')
      +'<div class="ref-auto-speed"><input type="range" min="1" max="100" value="'+state.speed+'" data-slider="speed"><output id="speed-value">'+state.speed+'</output></div>'
      +'<div class="ref-auto-bright"><input type="range" min="1" max="100" value="'+state.brightness+'" data-slider="brightness"><output id="brightness-value">'+state.brightness+'</output></div>'
      +[0,1,2,3,5].map((v,i)=>'<button type="button" class="ref-delay d'+i+' '+(state.delay===v?'active':'')+'" data-delay="'+v+'"></button>').join('')
      +'<button type="button" class="ref-save-auto" data-action="auto-save"></button></div>';
  }
  function refHomeView(){
    const rgb=currentRgb();
    return '<div class="ref-page home"><img class="ref-img" src="ref/home.jpg" alt=""><button type="button" class="ref-home-menu" data-page="settings" aria-label="Menu"></button><button type="button" class="ref-home-gear" data-page="mode210" aria-label="210 Mode"></button>'
      +'<div id="hue-wheel" class="ref-home-wheel" role="slider" tabindex="0"><i class="ref-hue-dot" id="ref-hue-dot"></i></div>'
      +'<button id="power" class="ref-power '+(state.power?'on':'')+'" type="button"></button>'
      +'<div class="ref-rgb-values"><span id="rgb-0">'+rgb[0]+'</span><span id="rgb-1">'+rgb[1]+'</span><span id="rgb-2">'+rgb[2]+'</span></div>'
      +presets.map((c,i)=>'<button type="button" class="ref-preset p'+i+'" data-preset="'+i+'"></button>').join('')
      +state.quick.map((v,i)=>'<button type="button" class="ref-quick q'+i+' '+(v?'saved':'')+'" data-quick="'+i+'" style="'+(v?'--q:'+v:'')+'"></button>').join('')
      +'<div class="ref-home-bright"><input type="range" min="1" max="100" value="'+state.brightness+'" data-slider="brightness"><output id="brightness-value">'+state.brightness+'%</output></div>'
      +'<div class="ref-home-speed"><input type="range" min="1" max="100" value="'+state.speed+'" data-slider="speed"><output id="speed-value">'+state.speed+'%</output></div>'
      +'</div>';
  }

  function refreshRefVisuals(){
    document.querySelectorAll('.ref-cardtap[data-mode-channel]').forEach(card=>{
      const i=Number(card.dataset.modeChannel),on=i===4?allChannelsOn():state.channelEnabled[i],mixed=i===4&&anyChannelsOn()&&!allChannelsOn();
      card.classList.toggle('active-ref',state.channel===i);
      card.classList.toggle('ref-off',!on&&!mixed);
      const val=document.querySelector('.ref-cardval.c'+i);
      if(val)val.textContent=cardModeValue(i);
      const t=document.querySelector('.ref-toggle.c'+i);
      if(t){t.classList.toggle('on',on);t.classList.toggle('mixed',mixed);t.setAttribute('aria-pressed',String(on));}
    });
    if(specs[page]){
      const v=selectedModeValue(page,state.channel);
      const center=document.getElementById('dial-number'); if(center)center.innerHTML=sevenSeg(v);
      const live=document.getElementById('ref-live-mode'); if(live)live.textContent=v;
    }
  }
  function refSettingsView(){
    const targets=['device','welcome','standby','sein','rem','mundur','auto','about','privacy','password','wallpaper','bahasa'];
    return '<div class="ref-page settings"><img class="ref-img" src="ref/settings.jpg" alt=""><button type="button" class="ref-back" data-page="home" aria-label="Kembali"></button>'
      +targets.map((t,i)=>'<button type="button" class="ref-settings-row r'+i+'" data-page="'+t+'"></button>').join('')+'</div>';
  }
  function refBahasaView(){
    return '<div class="ref-page bahasa"><img class="ref-img" src="ref/bahasa.jpg" alt=""><button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button><button class="ref-lang l0" type="button"></button><button class="ref-lang l1" type="button"></button><button class="ref-lang l2" type="button"></button></div>';
  }
  function refPasswordView(){
    return '<div class="ref-page password"><img class="ref-img" src="ref/password.jpg" alt=""><button type="button" class="ref-back" data-page="settings" aria-label="Kembali"></button></div>';
  }

  function render(){
    nav.textContent=page==='home'?'☰':'←';nav.setAttribute('aria-label',page==='home'?'Buka menu':'Kembali');
    document.body.classList.toggle('home-page',page==='home');
    document.body.classList.toggle('settings-page',page==='settings');document.body.classList.toggle('mode-page',!!specs[page]||page==='auto');
    if(specs[page]){brandEl.innerHTML='<span class="rainbow">MODE</span> '+specs[page].title;settingsShortcut.innerHTML='<span class="mode-h-mark">H</span>';settingsShortcut.setAttribute('aria-label','HS JAYA LIGHTING');}
    else if(page==='auto'){brandEl.innerHTML='<span class="rainbow">AUTO</span> MODE';settingsShortcut.innerHTML='<span class="mode-h-mark">H</span>';settingsShortcut.setAttribute('aria-label','HS JAYA LIGHTING');}
    else{brandEl.innerHTML='<span class="rainbow">RGB</span> <span>HYBRID</span>';settingsShortcut.innerHTML='<span class="overflow-glyph" aria-hidden="true"><i></i><i></i><i></i></span>';settingsShortcut.setAttribute('aria-label','Setelan');}
    settingsShortcut.style.visibility=['settings','device'].includes(page)?'hidden':'visible';
    content.innerHTML=page==='home'?refHomeView():specs[page]?refModeView(page):page==='auto'?refAutoView():page==='settings'?refSettingsView():page==='device'?deviceView():page==='password'?refPasswordView():page==='bahasa'?refBahasaView():page==='about'?simplePage('ABOUT RGB HYBRID','Aplikasi HS JAYA untuk mengontrol modul LEDCAR-02-9931 dengan koneksi Bluetooth BLE. Versi 1.1.0.'):page==='privacy'?simplePage('PRIVACY POLICY','Aplikasi bekerja secara lokal lewat Bluetooth. Teks kebijakan privasi resmi belum tersedia.'):simplePage('WALLPAPER','Pilihan wallpaper khusus belum tersedia dalam versi ini.');
    renderLinks();updateConnection();
    if(page==='home')updateWheel();
    refreshRefVisuals();
  }
  function updateWheel(){
    const wheel=document.getElementById('hue-wheel');if(!wheel)return;wheel.setAttribute('aria-valuenow',String(state.hue));
    currentRgb().forEach((v,i)=>{let el=document.getElementById('rgb-'+i);if(el)el.textContent=String(v);});
    const dot=document.getElementById('ref-hue-dot');
    if(dot){const a=state.hue*Math.PI/180,r=.39;dot.style.left=(50+Math.cos(a)*r*100)+'%';dot.style.top=(50-Math.sin(a)*r*100)+'%';}
  }
  function chooseHue(h,transmit){state.hue=((Math.round(h)%360)+360)%360;state.rgb=rgbForHue(state.hue);rememberRgb(state.rgb,state.channel);persist();updateWheel();if(transmit)sendRgbSelection(state.rgb,state.channel);}
  function choosePreset(index){const hex=presets[index];state.rgb=hex.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));const selection=state.channel;rememberRgb(state.rgb,selection);persist();if(page==='home')updateWheel();sendRgbSelection(state.rgb,selection);}
  function modeValue(v,transmit){let spec=specs[page];if(!spec)return;v=clamp(v,spec.min,spec.max);
    const arr=pageModeArray(page),mixedAll=state.channel===4&&!arr.every(x=>x===arr[0]),old=selectedModeValue(page,state.channel);if(old===v&&!mixedAll)return;
    setSelectedModeValue(page,v,state.channel);
    if(page==='mode210')rememberMode210(v,state.channel);
    persist();let output=document.getElementById('dial-number');if(output)output.innerHTML=sevenSeg(v);
    refreshCurvedTicks();refreshRefVisuals();
    document.querySelectorAll('[data-mode-card-channel]').forEach(card=>{const i=Number(card.dataset.modeCardChannel),b=card.querySelector('b');if(b)b.textContent=cardModeValue(i);});
    if(transmit&&!spec.local)sendPageModeSelection(v,state.channel);
  }
  function scrollRuler(v,behavior){refreshCurvedTicks();}
  function sliderInput(el,final){let name=el.dataset.slider,val=clamp(el.value,1,100),rem=page==='rem';let key=rem?(name==='brightness'?'remBrightness':'remSpeed'):name;state[key]=val;persist();let output=document.getElementById(name+'-value');if(output)output.textContent=page==='home'?(val+'%'):String(val);if(specs[page]&&specs[page].local)return;
    if(final||Date.now()-lastSliderAt>170){lastSliderAt=Date.now();if(rem)send('remSetting',name==='brightness'?1:2,val);else send('send',name==='brightness'?1:2,val,3);}
  }
  function hsvToRgb(h,s,v){let c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c,r=0,g=0,b=0;if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}return [r,g,b].map(n=>Math.round((n+m)*255));}
  function wheelPointer(ev){let box=ev.currentTarget.getBoundingClientRect(),dx=ev.clientX-(box.left+box.width/2),dy=ev.clientY-(box.top+box.height/2),radius=Math.min(box.width,box.height)/2,dist=Math.min(radius,Math.hypot(dx,dy));return {h:(360-Math.atan2(dy,dx)*180/Math.PI)%360,s:Math.min(1,dist/(radius*.94))};}
  function chooseWheelPoint(point,transmit){state.hue=((Math.round(point.h)%360)+360)%360;state.rgb=hsvToRgb(state.hue,point.s,1);rememberRgb(state.rgb,state.channel);persist();updateWheel();if(transmit)sendRgbSelection(state.rgb,state.channel);}
  function commitPendingQuick(){if(pendingQuickSlot===null)return;state.quick[pendingQuickSlot]=currentHex();let slot=pendingQuickSlot;pendingQuickSlot=null;persist();render();flash('Warna disimpan di Quick Save '+(slot+1));}

  content.addEventListener('pointerdown',ev=>{if(ev.target.closest('[data-channel-toggle],[data-mode-channel],[data-channel]')){ev.stopPropagation();}const wheel=ev.target.closest('#hue-wheel'),dial=ev.target.closest('#dial'),quick=ev.target.closest('[data-quick]');if(wheel){wheelStart=wheel;wheel.setPointerCapture(ev.pointerId);chooseWheelPoint(wheelPointer(ev),false);ev.preventDefault();}if(dial){dialStart={x:ev.clientX,v:selectedModeValue(page,state.channel)};dial.setPointerCapture(ev.pointerId);}if(quick){quick.dataset.held='0';quick._long=setTimeout(()=>{quick.dataset.held='1';pendingQuickSlot=Number(quick.dataset.quick);flash('Geser pilih warna di lingkaran, lalu lepas jari');},650);}});
  content.addEventListener('pointermove',ev=>{if(wheelStart&&ev.target.closest('#hue-wheel')){chooseWheelPoint(wheelPointer(ev),Date.now()-wheelLastAt>125);wheelLastAt=Date.now();}if(dialStart){let diff=dialStart.x-ev.clientX;if(Math.abs(diff)>8)modeValue(dialStart.v+Math.round(diff/24),false);}});
  content.addEventListener('pointerup',ev=>{if(wheelStart){chooseWheelPoint(wheelPointer(ev),true);wheelStart=null;commitPendingQuick();}if(dialStart){let selected=selectedModeValue(page,state.channel);dialStart=null;scrollRuler(selected,'smooth');if(specs[page]&&!specs[page].local)sendPageModeSelection(selected,state.channel);}let quick=ev.target.closest('[data-quick]');if(quick)clearTimeout(quick._long);});
  content.addEventListener('pointercancel',()=>{wheelStart=null;dialStart=null;});
  content.addEventListener('scroll',ev=>{if(ev.target.id!=='mode-ruler'||!specs[page])return;let selected=clamp(Math.round(ev.target.scrollLeft/58)+specs[page].min,specs[page].min,specs[page].max),current=selectedModeValue(page,state.channel);if(current===selected)return;modeValue(selected,false);clearTimeout(rulerTimer);rulerTimer=setTimeout(()=>{if(specs[page]&&!specs[page].local)sendPageModeSelection(selected,state.channel);},180);},true);
  content.addEventListener('input',ev=>{if(ev.target.matches('[data-slider]'))sliderInput(ev.target,false);});
  content.addEventListener('change',ev=>{if(ev.target.matches('[data-slider]'))sliderInput(ev.target,true);});
  content.addEventListener('keydown',ev=>{if(ev.target.id==='hue-wheel'){if(ev.key==='ArrowLeft'||ev.key==='ArrowRight'){chooseHue(state.hue+(ev.key==='ArrowRight'?3:-3),true);ev.preventDefault();}}});
  content.addEventListener('click',ev=>{
    const target=ev.target.closest('button');if(!target)return;
    if(target.dataset.page){navigate(target.dataset.page);return;}
    if(target.dataset.channelToggle!==undefined){ev.preventDefault();ev.stopPropagation();toggleSoftChannel(Number(target.dataset.channelToggle));return;}
    if(target.dataset.channel!==undefined){selectChannel(Number(target.dataset.channel));return;}
    if(target.dataset.modeChannel!==undefined){selectModeChannel(Number(target.dataset.modeChannel));return;}
    if(target.dataset.modeValue!==undefined){const v=Number(target.dataset.modeValue);modeValue(v,true);scrollRuler(v,'smooth');return;}
    if(target.dataset.preset!==undefined){choosePreset(Number(target.dataset.preset));return;}
    if(target.dataset.quick!==undefined){if(target.dataset.held==='1'){target.dataset.held='0';return;}let i=Number(target.dataset.quick),v=state.quick[i];if(!v){pendingQuickSlot=i;flash('Pilih warna di lingkaran, lalu lepas jari untuk menyimpan');}else{state.rgb=v.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16));rememberRgb(state.rgb,state.channel);persist();updateWheel();sendRgbSelection(state.rgb,state.channel);flash('Warna slot '+(i+1)+' digunakan');}return;}
    if(target.dataset.delay!==undefined){state.delay=Number(target.dataset.delay);persist();render();return;}
    if(target.dataset.area!==undefined){if(send('subareaDouble',Number(target.dataset.area)))flash('Subarea '+target.dataset.area+' dikirim');return;}
    if(target.id==='power'){let next=!state.power;if(!send('send',4,next?1:0,3))return;state.power=next;persist();target.classList.toggle('on',state.power);target.setAttribute('aria-label','Lampu '+(state.power?'mati':'nyala'));if(next)scheduleSoftOffReapply();return;}
    switch(target.dataset.action){
      case 'connect': if(!window.HsNative){flash('Bluetooth tersedia di APK Android');break;}ready?window.HsNative.disconnect():window.HsNative.connect();break;
      case 'pixel':{let field=document.getElementById('pixel');let val=clamp(field.value,1,1000);field.value=val;state.pixel=val;persist();if(send('pixel',val))flash('Jumlah LED '+val+' dikirim');break;}
      case 'mode-save':{let spec=specs[page],v=selectedModeValue(page,state.channel);persist();if(spec.local){flash('LED '+(state.channel===4?'ALL':state.channel+1)+' · Mode '+v+' disimpan di ponsel');break;}let ok=sendPageModeSelection(v,state.channel);if(ok)flash('Mode '+v+' dikirim');break;}
      case 'auto-save':if(send('send',3,255,3)){scheduleSoftOffReapply();flash('AUTO bawaan MCU diaktifkan');}break;
      case 'lock':if(send('send',22,1,3))flash('Kunci modul dikirim');break;
      case 'unlock':if(send('send',22,0,3))flash('Buka kunci modul dikirim');break;
      case 'ota':if(window.HsNative)window.HsNative.ota();else flash('Tautan OTA tersedia di APK');break;
    }
  });
  document.getElementById('drawer-links').addEventListener('click',ev=>{let link=ev.target.closest('[data-page]');if(link){ev.preventDefault();navigate(link.dataset.page);}});
  document.getElementById('drawer-close').addEventListener('click',()=>setDrawer(false));backdrop.addEventListener('click',()=>setDrawer(false));
  nav.addEventListener('click',()=>page==='home'?navigate('settings'):window.hsGoBack());settingsShortcut.addEventListener('click',()=>navigate('settings'));
  document.getElementById('connection').addEventListener('click',ev=>{if(!ev.target.closest('#connect'))return;if(!window.HsNative){flash('Bluetooth hanya tersedia dalam APK Android');return;}ready?window.HsNative.disconnect():window.HsNative.connect();});
  render();
})();
