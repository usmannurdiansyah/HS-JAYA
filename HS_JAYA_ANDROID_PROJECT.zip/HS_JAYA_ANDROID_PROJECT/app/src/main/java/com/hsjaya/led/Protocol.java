package com.hsjaya.led;

/** LEDCAR/LEDLAMP firmware protocol. All commands use FFE0/FFE1. */
final class Protocol {
    static final int ALL = 0x03;
    static final int[] CHANNELS = {0x01, 0x02, 0x04, 0x05, ALL};

    private Protocol() { }

    static byte[] simple(int command, int value, int channel) {
        byte[] p = base(command, channel);
        p[2] = (byte) value;
        return p;
    }

    static byte[] rgb(int r, int g, int b, int channel) {
        byte[] p = base(0x07, channel);
        p[2] = (byte) r;
        p[3] = (byte) g;
        p[4] = (byte) b;
        return p;
    }

    static byte[] ledCount(int count) {
        byte[] p = base(0x05, ALL);
        p[3] = (byte) (count >> 8);
        p[4] = (byte) count;
        return p;
    }

    static byte[] remSetting(int command, int value) {
        byte[] p = simple(command, value, ALL);
        p[3] = 0x04;
        return p;
    }

    private static byte[] base(int command, int channel) {
        byte[] p = new byte[9];
        p[0] = 0x7B;
        p[1] = (byte) command;
        p[7] = (byte) channel;
        p[8] = (byte) 0xBF;
        return p;
    }
}
