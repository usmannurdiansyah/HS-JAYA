package com.hsjaya.led;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.content.Intent;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

final class BleController {
    interface Listener { void onStatus(String status, boolean ready); }

    static final int PERMISSION_REQUEST = 401;
    private static final UUID SERVICE = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHARACTERISTIC = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final ArrayDeque<byte[]> pending = new ArrayDeque<>();
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private boolean scanning;
    private boolean draining;

    BleController(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    boolean ready() { return gatt != null && tx != null; }

    boolean permissionsGranted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void scan() {
        if (!permissionsGranted()) {
            if (Build.VERSION.SDK_INT >= 31) activity.requestPermissions(
                    new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, PERMISSION_REQUEST);
            else activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST);
            return;
        }
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { message("Bluetooth tidak tersedia"); return; }
        if (!adapter.isEnabled()) {
            message("Aktifkan Bluetooth dulu");
            activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { message("Pemindai BLE tidak tersedia"); return; }
        if (scanning) return;
        found.clear();
        scanning = true;
        status("Mencari modul LED…", false);
        try { scanner.startScan(scanCallback); }
        catch (SecurityException error) { scanning = false; message("Izin Bluetooth diperlukan"); return; }
        main.postDelayed(() -> {
            if (!scanning) return;
            stopScan();
            showDevices();
        }, 7000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            try {
                BluetoothDevice device = result.getDevice();
                String name = device.getName();
                if ((name == null || name.isEmpty()) && result.getScanRecord() != null)
                    name = result.getScanRecord().getDeviceName();
                String upper = name == null ? "" : name.toUpperCase(Locale.ROOT);
                boolean expectedName = upper.contains("LEDCAR") || upper.contains("LEDLAMP")
                        || upper.contains("WARDAN") || upper.contains("HS JAYA") || upper.contains("HS-JAYA");
                boolean service = false;
                if (result.getScanRecord() != null && result.getScanRecord().getServiceUuids() != null)
                    for (ParcelUuid id : result.getScanRecord().getServiceUuids())
                        if (SERVICE.equals(id.getUuid())) { service = true; break; }
                if (expectedName || service) {
                    String address = device.getAddress();
                    main.post(() -> found.put(address, device));
                }
            } catch (SecurityException ignored) { }
        }

        @Override public void onScanFailed(int errorCode) {
            main.post(() -> { stopScan(); status("Scan gagal (" + errorCode + ")", false); });
        }
    };

    private void showDevices() {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        if (found.isEmpty()) { status("Modul tidak ditemukan", false); message("Cek daya modul, lalu coba Hubungkan lagi"); return; }
        ArrayList<BluetoothDevice> devices = new ArrayList<>(found.values());
        String[] labels = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            try {
                String name = devices.get(i).getName();
                labels[i] = (name == null || name.isEmpty() ? "Modul LED" : name)
                        + "  ·  " + devices.get(i).getAddress();
            } catch (SecurityException error) { labels[i] = "Modul LED " + (i + 1); }
        }
        new AlertDialog.Builder(activity).setTitle("Pilih modul LED")
                .setItems(labels, (dialog, which) -> connect(devices.get(which)))
                .setNegativeButton("Batal", null).show();
    }

    private void connect(BluetoothDevice device) {
        if (!permissionsGranted()) return;
        disconnect();
        status("Menghubungkan…", false);
        try { gatt = device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE); }
        catch (SecurityException error) { status("Izin Bluetooth diperlukan", false); }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt source, int code, int state) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                try { source.discoverServices(); }
                catch (SecurityException error) { status("Izin Bluetooth diperlukan", false); }
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                main.post(() -> {
                    if (gatt != source) return;
                    tx = null;
                    pending.clear();
                    draining = false;
                    source.close();
                    gatt = null;
                    status("Terputus", false);
                });
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt source, int code) {
            main.post(() -> {
                if (gatt != source) return;
                BluetoothGattService service = code == BluetoothGatt.GATT_SUCCESS ? source.getService(SERVICE) : null;
                tx = service == null ? null : service.getCharacteristic(CHARACTERISTIC);
                status(tx == null ? "FFE1 tidak tersedia" : "Terhubung · FFE1 siap", tx != null);
            });
        }
    };

    void write(byte[] packet) {
        if (!ready()) { message("Hubungkan modul dulu"); return; }
        pending.add(packet.clone());
        if (!draining) { draining = true; main.post(this::drain); }
    }

    private void drain() {
        if (!ready()) { pending.clear(); draining = false; return; }
        byte[] data = pending.poll();
        if (data == null) { draining = false; return; }
        try {
            int writeType = (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            boolean ok;
            if (Build.VERSION.SDK_INT >= 33)
                ok = gatt.writeCharacteristic(tx, data, writeType) == 0;
            else {
                tx.setWriteType(writeType);
                tx.setValue(data);
                ok = gatt.writeCharacteristic(tx);
            }
            if (!ok) message("Perintah BLE gagal dikirim");
        } catch (SecurityException error) { message("Izin Bluetooth diperlukan"); }
        catch (Exception error) { message("Koneksi BLE bermasalah"); }
        main.postDelayed(this::drain, 110);
    }

    private void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && permissionsGranted()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    void disconnect() {
        stopScan();
        pending.clear();
        draining = false;
        tx = null;
        BluetoothGatt old = gatt;
        gatt = null;
        if (old != null) {
            try { if (permissionsGranted()) old.disconnect(); }
            catch (SecurityException ignored) { }
            old.close();
        }
        status("Belum terhubung", false);
    }

    private void status(String text, boolean ready) { main.post(() -> listener.onStatus(text, ready)); }
    private void message(String text) { main.post(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()); }
}
