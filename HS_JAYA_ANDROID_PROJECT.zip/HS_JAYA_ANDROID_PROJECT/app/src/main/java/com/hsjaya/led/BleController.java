package com.hsjaya.led;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Multi-device BLE manager.
 *
 * Supports multiple stock LEDCAR/LEDDMX controllers and multiple HS JAYA custom
 * controllers at the same time.  Protocol routing is per connection, so one UI
 * action can be translated into different wire packets for different devices.
 */
final class BleController {
    interface Listener {
        void onStatus(String status, int readyCount, int customCount, int stockLedcarCount, int stockDmxCount);
    }

    static final int PERMISSION_REQUEST = 401;
    private static final int MAX_CONNECTIONS = 10;
    private static final long SCAN_MS = 4200L;
    private static final long CONNECT_STAGGER_MS = 220L;
    private static final long WRITE_GAP_MS = 65L;

    private static final UUID SERVICE = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHARACTERISTIC = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final UUID CUSTOM_OTA_SERVICE = UUID.fromString("7e400001-b5a3-f393-e0a9-e50e24dcca9e");

    private static final String PREFS = "hsjaya_ble";
    private static final String PREF_SELECTED = "selected_addresses";

    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;

    private final Map<String, DeviceChoice> found = new LinkedHashMap<>();
    private final Map<String, Connection> connections = new LinkedHashMap<>();

    private BluetoothLeScanner scanner;
    private boolean scanning;
    private boolean scanAutomatic;
    private boolean pendingPermissionScan;
    private boolean pendingPermissionAuto;
    private boolean shuttingDown;
    private int scanGeneration;

    private static final class DeviceChoice {
        final BluetoothDevice device;
        final String address;
        final String rawName;
        final int rssi;
        final Protocol.Profile profile;
        final boolean custom;
        final boolean supported;

        DeviceChoice(BluetoothDevice device, String address, String rawName, int rssi,
                     Protocol.Profile profile, boolean custom, boolean supported) {
            this.device = device;
            this.address = address;
            this.rawName = rawName;
            this.rssi = rssi;
            this.profile = profile;
            this.custom = custom;
            this.supported = supported;
        }
    }

    private final class Connection {
        final DeviceChoice choice;
        final ArrayDeque<byte[]> pending = new ArrayDeque<>();
        BluetoothGatt gatt;
        BluetoothGattCharacteristic tx;
        boolean connecting;
        boolean ready;
        boolean draining;

        Connection(DeviceChoice choice) { this.choice = choice; }
    }

    BleController(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    boolean permissionsGranted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void autoConnect() { scanInternal(true); }
    void scan() { scanInternal(false); }

    void resumePendingScan() {
        if (!pendingPermissionScan) return;
        boolean auto = pendingPermissionAuto;
        pendingPermissionScan = false;
        pendingPermissionAuto = false;
        scanInternal(auto);
    }

    private void scanInternal(boolean automatic) {
        if (shuttingDown) return;
        if (!permissionsGranted()) {
            pendingPermissionScan = true;
            pendingPermissionAuto = automatic;
            status("Meminta izin Bluetooth dan Lokasi…");
            if (Build.VERSION.SDK_INT >= 31) {
                activity.requestPermissions(new String[]{
                        Manifest.permission.BLUETOOTH_SCAN,
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, PERMISSION_REQUEST);
            } else {
                activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST);
            }
            return;
        }

        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { status("Bluetooth tidak tersedia"); return; }
        if (!adapter.isEnabled()) {
            status("Aktifkan Bluetooth, lalu buka HS JAYA kembali");
            activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { status("Pemindai BLE tidak tersedia"); return; }
        if (scanning) return;

        found.clear();
        scanAutomatic = automatic;
        scanning = true;
        final int generation = ++scanGeneration;
        status(automatic ? "Menghubungkan otomatis…" : "Mencari RGB HYBRID…");
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            scanner.startScan(null, settings, scanCallback);
        } catch (SecurityException error) {
            scanning = false;
            status("Izin Bluetooth/Lokasi diperlukan");
            return;
        } catch (Exception error) {
            scanning = false;
            status("Scan BLE gagal dimulai");
            return;
        }

        main.postDelayed(() -> finishScan(automatic, generation), SCAN_MS);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            try {
                BluetoothDevice device = result.getDevice();
                ScanRecord record = result.getScanRecord();
                String name = record == null ? null : record.getDeviceName();
                if (name == null || name.isEmpty()) name = device.getName();
                if (name == null) name = "";
                String address = device.getAddress();
                boolean hasFfe0 = hasService(record, SERVICE);
                boolean custom = hasService(record, CUSTOM_OTA_SERVICE) || looksCustom(name);
                Protocol.Profile profile = classify(name, custom);
                boolean nameLooksSupported = looksSupportedName(name);
                boolean supported = profile != Protocol.Profile.UNKNOWN || hasFfe0 || custom || nameLooksSupported;
                if (!supported) return;

                // If the name is unknown but FFE0 is present, default to compact framing.
                // This is the safest fallback for the user's LEDCAR-02 / LEDDMX-04 modules.
                if (profile == Protocol.Profile.UNKNOWN && hasFfe0) profile = Protocol.Profile.B_COMPACT;

                DeviceChoice choice = new DeviceChoice(device, address, name, result.getRssi(), profile, custom, true);
                synchronized (found) { found.put(address, choice); }
            } catch (SecurityException ignored) { }
        }

        @Override public void onScanFailed(int errorCode) {
            main.post(() -> {
                stopScan();
                status("Scan BLE gagal (kode " + errorCode + ")");
            });
        }
    };

    private void finishScan(boolean automatic, int generation) {
        if (!scanning || generation != scanGeneration) return;
        stopScan();
        List<DeviceChoice> choices = supportedChoices();
        if (choices.isEmpty()) {
            status("Modul LED belum ditemukan · cek daya atau koneksi aplikasi lama");
            return;
        }

        if (automatic) {
            Set<String> preferred = new LinkedHashSet<>(prefs.getStringSet(PREF_SELECTED, Collections.emptySet()));
            List<DeviceChoice> selected = new ArrayList<>();
            if (!preferred.isEmpty()) {
                for (DeviceChoice choice : choices) if (preferred.contains(choice.address)) selected.add(choice);
            }
            // If none of the remembered devices are present, recover automatically by
            // connecting every supported controller currently visible.
            if (selected.isEmpty()) selected.addAll(choices);
            connectSelected(selected, false);
        } else {
            showSelectionDialog(choices);
        }
    }

    private List<DeviceChoice> supportedChoices() {
        ArrayList<DeviceChoice> list = new ArrayList<>();
        synchronized (found) {
            for (DeviceChoice choice : found.values()) {
                if (choice.supported) list.add(choice);
                if (list.size() >= MAX_CONNECTIONS) break;
            }
        }
        return list;
    }

    private void showSelectionDialog(List<DeviceChoice> choices) {
        if (choices.isEmpty()) return;
        Set<String> preferred = new LinkedHashSet<>(prefs.getStringSet(PREF_SELECTED, Collections.emptySet()));
        String[] labels = new String[choices.size()];
        boolean[] checked = new boolean[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            DeviceChoice c = choices.get(i);
            String tail = c.address.length() >= 5 ? c.address.substring(c.address.length() - 5) : c.address;
            labels[i] = "RGB HYBRID " + (i + 1) + "  ·  " + c.rssi + " dBm  ·  …" + tail;
            checked[i] = preferred.isEmpty() || preferred.contains(c.address);
        }

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("Pilih perangkat · bisa lebih dari satu")
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("Batal", null)
                .setPositiveButton("HUBUNGKAN TERPILIH", null)
                .create();
        dialog.setOnShowListener(ignore -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            ArrayList<DeviceChoice> selected = new ArrayList<>();
            for (int i = 0; i < choices.size(); i++) if (checked[i]) selected.add(choices.get(i));
            if (selected.isEmpty()) {
                message("Pilih minimal satu perangkat");
                return;
            }
            connectSelected(selected, true);
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void connectSelected(List<DeviceChoice> requested, boolean replaceExisting) {
        if (requested == null || requested.isEmpty()) return;
        ArrayList<DeviceChoice> selected = new ArrayList<>();
        LinkedHashSet<String> addresses = new LinkedHashSet<>();
        for (DeviceChoice choice : requested) {
            if (choice == null || addresses.contains(choice.address)) continue;
            selected.add(choice);
            addresses.add(choice.address);
            if (selected.size() >= MAX_CONNECTIONS) break;
        }
        prefs.edit().putStringSet(PREF_SELECTED, addresses).apply();

        if (replaceExisting) disconnectAllInternal(false);
        status("Menghubungkan " + selected.size() + " perangkat…");
        for (int i = 0; i < selected.size(); i++) {
            DeviceChoice choice = selected.get(i);
            main.postDelayed(() -> connectOne(choice), i * CONNECT_STAGGER_MS);
        }
    }

    private void connectOne(DeviceChoice choice) {
        if (choice == null || shuttingDown || !permissionsGranted()) return;
        Connection existing = connections.get(choice.address);
        if (existing != null && (existing.ready || existing.connecting)) return;
        if (connections.size() >= MAX_CONNECTIONS) return;

        Connection connection = new Connection(choice);
        connection.connecting = true;
        connections.put(choice.address, connection);
        try {
            connection.gatt = choice.device.connectGatt(activity, false, new GattCallback(connection), BluetoothDevice.TRANSPORT_LE);
            if (connection.gatt == null) {
                connections.remove(choice.address);
                publishStatus();
                return;
            }
            BluetoothGatt attempt = connection.gatt;
            main.postDelayed(() -> {
                if (connection.gatt != attempt || connection.ready || !connection.connecting) return;
                closeConnection(connection, false);
                publishStatus();
            }, 14000L);
        } catch (SecurityException error) {
            connections.remove(choice.address);
            publishStatus();
        } catch (Exception error) {
            connections.remove(choice.address);
            publishStatus();
        }
    }

    private final class GattCallback extends BluetoothGattCallback {
        private final Connection connection;
        GattCallback(Connection connection) { this.connection = connection; }

        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            main.post(() -> handleConnectionState(connection, g, status, newState));
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            main.post(() -> handleServicesDiscovered(connection, g, status));
        }
    }

    private void handleConnectionState(Connection connection, BluetoothGatt g, int status, int newState) {
        if (g != connection.gatt) return;
        if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
            connection.connecting = false;
            try {
                if (permissionsGranted()) g.discoverServices();
            } catch (SecurityException error) {
                closeConnection(connection, false);
                publishStatus();
            }
            return;
        }
        if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            closeConnection(connection, false);
            publishStatus();
        }
    }

    private void handleServicesDiscovered(Connection connection, BluetoothGatt g, int status) {
        if (g != connection.gatt) return;
        if (status != BluetoothGatt.GATT_SUCCESS) {
            closeConnection(connection, false);
            publishStatus();
            return;
        }
        BluetoothGattService service = g.getService(SERVICE);
        BluetoothGattCharacteristic characteristic = service == null ? null : service.getCharacteristic(CHARACTERISTIC);
        if (characteristic == null) {
            closeConnection(connection, false);
            publishStatus();
            return;
        }
        characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        connection.tx = characteristic;
        connection.ready = true;
        connection.connecting = false;
        publishStatus();
    }

    void send(int command, int value, int channel) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.simple(connection.choice.profile, command, value, channel);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void rgb(int r, int g, int b, int channel) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.rgb(connection.choice.profile, r, g, b, channel);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void pixel(int count) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.ledCount(connection.choice.profile, count);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void remSetting(int command, int value) {
        for (Connection connection : readyConnections()) {
            byte[] packet = Protocol.remSetting(connection.choice.profile, command, value);
            if (packet != null) enqueue(connection, packet);
        }
    }

    void subareaDouble(int area) {
        for (Connection connection : readyConnections()) {
            if (connection.choice.profile != Protocol.Profile.CUSTOM) continue;
            byte[] packet = Protocol.simple(Protocol.Profile.CUSTOM, 0x14, area, Protocol.ALL);
            if (packet == null) continue;
            enqueue(connection, packet);
            main.postDelayed(() -> enqueue(connection, packet.clone()), 160L);
        }
    }

    private List<Connection> readyConnections() {
        ArrayList<Connection> list = new ArrayList<>();
        for (Connection c : connections.values()) if (c.ready && c.tx != null && c.gatt != null) list.add(c);
        return list;
    }

    private void enqueue(Connection connection, byte[] packet) {
        if (connection == null || packet == null || !connection.ready) return;
        synchronized (connection.pending) { connection.pending.offer(packet.clone()); }
        main.post(() -> drain(connection));
    }

    private void drain(Connection connection) {
        if (connection == null || connection.draining || !connection.ready || connection.gatt == null || connection.tx == null) return;
        byte[] packet;
        synchronized (connection.pending) { packet = connection.pending.poll(); }
        if (packet == null) return;
        connection.draining = true;
        try {
            connection.tx.setValue(packet);
            connection.tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            if (permissionsGranted()) connection.gatt.writeCharacteristic(connection.tx);
        } catch (SecurityException ignored) {
        } catch (Exception ignored) {
        }
        main.postDelayed(() -> {
            connection.draining = false;
            drain(connection);
        }, WRITE_GAP_MS);
    }

    void disconnectAll() {
        stopScan();
        disconnectAllInternal(true);
        publishStatus();
    }

    private void disconnectAllInternal(boolean manual) {
        ArrayList<Connection> copy = new ArrayList<>(connections.values());
        for (Connection connection : copy) closeConnection(connection, manual);
        connections.clear();
    }

    private void closeConnection(Connection connection, boolean manual) {
        if (connection == null) return;
        connection.ready = false;
        connection.connecting = false;
        connection.tx = null;
        connection.draining = false;
        synchronized (connection.pending) { connection.pending.clear(); }
        BluetoothGatt old = connection.gatt;
        connection.gatt = null;
        connections.remove(connection.choice.address);
        if (old != null) {
            try { if (permissionsGranted()) old.disconnect(); } catch (SecurityException ignored) { }
            try { old.close(); } catch (Exception ignored) { }
        }
    }

    void shutdown() {
        shuttingDown = true;
        stopScan();
        disconnectAllInternal(true);
    }

    void permissionsDenied() {
        pendingPermissionScan = false;
        pendingPermissionAuto = false;
        status("Izin Perangkat di sekitar dan Lokasi diperlukan");
    }

    private void publishStatus() {
        main.post(() -> {
            int ready = 0, custom = 0, stockLedcar = 0, stockDmx = 0;
            for (Connection c : connections.values()) {
                if (!c.ready) continue;
                ready++;
                if (c.choice.custom || c.choice.profile == Protocol.Profile.CUSTOM) custom++;
                else if (looksDmx(c.choice.rawName)) stockDmx++;
                else stockLedcar++;
            }
            String text;
            if (ready == 0) text = connections.isEmpty() ? "Belum terhubung" : "Menghubungkan…";
            else if (ready == 1) text = "1 perangkat terhubung";
            else text = ready + " perangkat terhubung";
            listener.onStatus(text, ready, custom, stockLedcar, stockDmx);
        });
    }

    private void status(String text) {
        main.post(() -> {
            int ready = 0, custom = 0, stockLedcar = 0, stockDmx = 0;
            for (Connection c : connections.values()) {
                if (!c.ready) continue;
                ready++;
                if (c.choice.custom || c.choice.profile == Protocol.Profile.CUSTOM) custom++;
                else if (looksDmx(c.choice.rawName)) stockDmx++;
                else stockLedcar++;
            }
            listener.onStatus(text, ready, custom, stockLedcar, stockDmx);
        });
    }

    private void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && permissionsGranted()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    private static boolean hasService(ScanRecord record, UUID uuid) {
        if (record == null || record.getServiceUuids() == null) return false;
        for (ParcelUuid id : record.getServiceUuids()) if (id != null && uuid.equals(id.getUuid())) return true;
        return false;
    }

    private static boolean looksCustom(String name) {
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        return u.contains("RGB HYBRID") || u.contains("HS JAYA") || u.contains("HS-JAYA");
    }

    private static boolean looksSupportedName(String name) {
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        return u.startsWith("LED") || looksCustom(name);
    }

    private static boolean looksDmx(String name) {
        return name != null && name.toUpperCase(Locale.ROOT).contains("LEDDMX");
    }

    private static Protocol.Profile classify(String name, boolean custom) {
        if (custom) return Protocol.Profile.CUSTOM;
        String u = name == null ? "" : name.toUpperCase(Locale.ROOT);
        if (u.startsWith("LEDCAR-02") || u.startsWith("LEDDMX-02") || u.startsWith("LEDDMX-04"))
            return Protocol.Profile.B_COMPACT;
        if (u.startsWith("LEDDMX") || u.startsWith("LEDCAR-01"))
            return Protocol.Profile.B_CLASSIC;
        if (u.startsWith("LEDCAR-00") || u.startsWith("LEDBLE"))
            return Protocol.Profile.A_GENERIC;
        if (u.startsWith("LEDCAR")) return Protocol.Profile.B_COMPACT;
        return Protocol.Profile.UNKNOWN;
    }

    private void message(String text) {
        main.post(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show());
    }
}
