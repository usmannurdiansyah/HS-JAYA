package com.hsjaya.led;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.provider.Settings;
import android.content.Intent;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

final class BleController {
    interface Listener { void onStatus(String status, boolean ready); }

    static final int PERMISSION_REQUEST = 401;
    private static final UUID SERVICE = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHARACTERISTIC = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, DeviceChoice> found = new LinkedHashMap<>();
    private final ArrayList<BluetoothDevice> displayed = new ArrayList<>();
    private final ArrayDeque<byte[]> pending = new ArrayDeque<>();
    private ArrayAdapter<String> deviceAdapter;
    private AlertDialog deviceDialog;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private boolean scanning;
    private boolean draining;

    private static final class DeviceChoice {
        final BluetoothDevice device;
        final String name;
        final boolean expected;
        final int rssi;
        DeviceChoice(BluetoothDevice device, String name, boolean expected, int rssi) {
            this.device = device; this.name = name; this.expected = expected; this.rssi = rssi;
        }
    }

    BleController(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    boolean ready() { return gatt != null && tx != null; }

    boolean permissionsGranted() {
        if (Build.VERSION.SDK_INT >= 31) {
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void scan() {
        if (!permissionsGranted()) {
            status("Meminta izin Bluetooth dan Lokasi…", false);
            if (Build.VERSION.SDK_INT >= 31) activity.requestPermissions(
                    new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT,
                            Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST);
            else activity.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST);
            return;
        }
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        if (adapter == null) { status("Bluetooth tidak tersedia", false); return; }
        if (!adapter.isEnabled()) {
            status("Aktifkan Bluetooth, lalu ketuk Cari & Hubungkan", false);
            activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { status("Pemindai BLE tidak tersedia", false); return; }
        if (scanning) return;
        found.clear();
        displayed.clear();
        deviceAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_list_item_1, new ArrayList<>());
        deviceDialog = new AlertDialog.Builder(activity)
                .setTitle("Mencari LEDCAR-02-9931…")
                .setAdapter(deviceAdapter, (dialog, which) -> {
                    if (which >= 0 && which < displayed.size()) connect(displayed.get(which));
                })
                .setNegativeButton("Batal", (dialog, which) -> stopScan())
                .setNeutralButton("Scan ulang", (dialog, which) -> {
                    stopScan(); main.postDelayed(this::scan, 280);
                }).create();
        deviceDialog.setOnDismissListener(dialog -> {
            stopScan(); deviceDialog = null; deviceAdapter = null;
        });
        deviceDialog.show();
        scanning = true;
        status("Mencari LEDCAR-02-9931…", false);
        try {
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null, settings, scanCallback);
        } catch (SecurityException error) {
            stopScan(); status("Izin Bluetooth/Lokasi diperlukan", false);
            if (deviceDialog != null) deviceDialog.dismiss();
            return;
        } catch (Exception error) {
            stopScan(); status("Scan BLE gagal dimulai", false);
            if (deviceDialog != null) deviceDialog.dismiss();
            return;
        }
        main.postDelayed(() -> {
            if (!scanning) return;
            stopScan();
            if (found.isEmpty()) {
                status("LEDCAR belum ditemukan · cek daya atau koneksi aplikasi lama", false);
                if (deviceDialog != null) deviceDialog.setTitle("Tidak ditemukan · tekan Scan ulang");
            } else {
                status("Pilih perangkat dalam daftar", false);
                if (deviceDialog != null) deviceDialog.setTitle("Pilih perangkat LED");
            }
        }, 12000);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            try {
                BluetoothDevice device = result.getDevice();
                String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
                if (name == null || name.isEmpty()) name = device.getName();
                String upper = name == null ? "" : name.toUpperCase(Locale.ROOT);
                boolean expectedName = upper.contains("LEDCAR") || upper.contains("LEDLAMP")
                        || upper.contains("WARDAN") || upper.contains("HS JAYA") || upper.contains("HS-JAYA");
                boolean service = false;
                if (result.getScanRecord() != null && result.getScanRecord().getServiceUuids() != null)
                    for (ParcelUuid id : result.getScanRecord().getServiceUuids())
                        if (SERVICE.equals(id.getUuid())) { service = true; break; }
                if (expectedName || service || (name != null && !name.isEmpty())) {
                    String address = device.getAddress();
                    String label = name == null || name.isEmpty() ? "Modul LED" : name;
                    boolean match = expectedName || service;
                    int rssi = result.getRssi();
                    main.post(() -> {
                        found.put(address, new DeviceChoice(device, label, match, rssi));
                        refreshDevices();
                    });
                }
            } catch (SecurityException ignored) { }
        }

        @Override public void onScanFailed(int errorCode) {
            main.post(() -> {
                stopScan(); status("Scan BLE gagal (kode " + errorCode + ")", false);
                if (deviceDialog != null) deviceDialog.setTitle("Scan gagal · tekan Scan ulang");
            });
        }
    };

    private void refreshDevices() {
        if (deviceDialog == null || deviceAdapter == null || !deviceDialog.isShowing()) return;
        deviceAdapter.clear(); displayed.clear();
        for (int pass = 0; pass < 2; pass++) {
            for (DeviceChoice choice : found.values()) {
                if (choice.expected != (pass == 0)) continue;
                displayed.add(choice.device);
                deviceAdapter.add((choice.expected ? "★ " : "• ") + choice.name
                        + "  ·  " + choice.device.getAddress() + "  (" + choice.rssi + " dBm)");
            }
        }
        deviceAdapter.notifyDataSetChanged();
        deviceDialog.setTitle("Pilih LEDCAR-02-9931 (★) atau modul FFE0");
    }

    private void connect(BluetoothDevice device) {
        if (!permissionsGranted()) return;
        disconnect();
        status("Menghubungkan…", false);
        try {
            gatt = device.connectGatt(activity, false, callback, BluetoothDevice.TRANSPORT_LE);
            BluetoothGatt attempt = gatt;
            if (attempt == null) { status("Gagal memulai koneksi BLE", false); return; }
            main.postDelayed(() -> {
                if (gatt != attempt || ready()) return;
                status("Koneksi habis waktu · coba lagi / tutup LEDCAR lama", false);
                disconnectGatt();
            }, 12000);
        } catch (SecurityException error) { status("Izin Bluetooth diperlukan", false); }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt source, int code, int state) {
            if (state == BluetoothProfile.STATE_CONNECTED && code == BluetoothGatt.GATT_SUCCESS) {
                status("Tersambung · mencari FFE0/FFE1…", false);
                try {
                    if (!source.discoverServices()) status("Gagal mencari layanan FFE0", false);
                } catch (SecurityException error) { status("Izin Bluetooth diperlukan", false); }
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                main.post(() -> {
                    if (gatt != source) return;
                    tx = null;
                    pending.clear();
                    draining = false;
                    source.close();
                    gatt = null;
                    status(code == BluetoothGatt.GATT_SUCCESS ? "Terputus" :
                            "Koneksi gagal (" + code + ") · coba lagi", false);
                });
            } else if (code != BluetoothGatt.GATT_SUCCESS) {
                main.post(() -> {
                    if (gatt != source) return;
                    status("Koneksi gagal (" + code + ") · coba lagi", false);
                    disconnectGatt();
                });
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt source, int code) {
            main.post(() -> {
                if (gatt != source) return;
                BluetoothGattService service = code == BluetoothGatt.GATT_SUCCESS ? source.getService(SERVICE) : null;
                tx = service == null ? null : service.getCharacteristic(CHARACTERISTIC);
                if (tx == null) {
                    status("FFE0/FFE1 tidak ada · pilih modul LEDCAR", false);
                    disconnectGatt();
                } else status("Terhubung · FFE1 siap", true);
            });
        }
    };

    void write(byte[] packet) {
        if (!ready()) { message("Hubungkan modul dulu"); return; }
        pending.add(packet.clone());
        if (!draining) { draining = true; main.post(this::drain); }
    }

    private void drain() {
        if (!ready()) { pending.clear(); draining = false; return; }
        byte[] data = pending.poll();
        if (data == null) { draining = false; return; }
        try {
            int writeType = (tx.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                    ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            boolean ok;
            if (Build.VERSION.SDK_INT >= 33)
                ok = gatt.writeCharacteristic(tx, data, writeType) == 0;
            else {
                tx.setWriteType(writeType);
                tx.setValue(data);
                ok = gatt.writeCharacteristic(tx);
            }
            if (!ok) message("Perintah BLE gagal dikirim");
        } catch (SecurityException error) { message("Izin Bluetooth diperlukan"); }
        catch (Exception error) { message("Koneksi BLE bermasalah"); }
        main.postDelayed(this::drain, 110);
    }

    private void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null && permissionsGranted()) scanner.stopScan(scanCallback); }
        catch (SecurityException ignored) { }
    }

    void disconnect() {
        stopScan();
        if (deviceDialog != null) deviceDialog.dismiss();
        disconnectGatt();
        status("Belum terhubung", false);
    }

    private void disconnectGatt() {
        pending.clear();
        draining = false;
        tx = null;
        BluetoothGatt old = gatt;
        gatt = null;
        if (old != null) {
            try { if (permissionsGranted()) old.disconnect(); }
            catch (SecurityException ignored) { }
            old.close();
        }
    }

    private void status(String text, boolean ready) { main.post(() -> listener.onStatus(text, ready)); }
    void permissionsDenied() { status("Izin Perangkat di sekitar dan Lokasi diperlukan", false); }
    private void message(String text) { main.post(() -> Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()); }
}
