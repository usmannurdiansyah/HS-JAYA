package com.hsjaya.led;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

/** Native BLE transport and an offline responsive interface packaged in this APK. */
public final class MainActivity extends Activity {
    private static final String OTA_URL = "https://ledcar-ota.usmannurdiansyah.workers.dev";
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private BleController ble;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(5, 5, 13));
        getWindow().setNavigationBarColor(Color.rgb(5, 5, 13));
        ble = new BleController(this, (status, ready) -> {
            if (web != null) web.evaluateJavascript("window.hsBleStatus(" +
                    JSONObject.quote(status) + "," + ready + ")", null);
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5, 5, 13));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setSupportZoom(false);
        web.getSettings().setBuiltInZoomControls(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.addJavascriptInterface(new NativeBridge(), "HsNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getHost())) return false;
                open(uri);
                return true;
            }
        });
        web.setOnApplyWindowInsetsListener((view, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        setContentView(web);
        web.requestApplyInsets();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void open(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception error) { Toast.makeText(this, "Browser tidak tersedia", Toast.LENGTH_SHORT).show(); }
    }

    public final class NativeBridge {
        @JavascriptInterface public void connect() { main.post(() -> ble.scan()); }
        @JavascriptInterface public void disconnect() { main.post(() -> ble.disconnect()); }
        @JavascriptInterface public void send(int cmd, int value, int channel) {
            main.post(() -> ble.write(Protocol.simple(cmd, value, channel)));
        }
        @JavascriptInterface public void rgb(int r, int g, int b, int channel) {
            main.post(() -> ble.write(Protocol.rgb(r, g, b, channel)));
        }
        @JavascriptInterface public void pixel(int count) {
            main.post(() -> ble.write(Protocol.ledCount(count)));
        }
        @JavascriptInterface public void remSetting(int cmd, int value) {
            main.post(() -> ble.write(Protocol.remSetting(cmd, value)));
        }
        @JavascriptInterface public void subareaDouble(int area) {
            main.post(() -> {
                ble.write(Protocol.simple(0x14, area, Protocol.ALL));
                main.postDelayed(() -> ble.write(Protocol.simple(0x14, area, Protocol.ALL)), 160);
            });
        }
        @JavascriptInterface public void ota() { main.post(() -> open(Uri.parse(OTA_URL))); }
        @JavascriptInterface public void exit() { main.post(MainActivity.this::finish); }
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request == BleController.PERMISSION_REQUEST) {
            if (ble.permissionsGranted()) ble.scan();
            else {
                ble.permissionsDenied();
                Toast.makeText(this, "Izinkan Perangkat di sekitar dan Lokasi agar modul LED ditemukan", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.hsGoBack()", null);
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        ble.disconnect();
        if (web != null) {
            web.removeJavascriptInterface("HsNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
