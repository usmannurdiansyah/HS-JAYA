# HS JAYA · RGB HYBRID

Aplikasi Android kedua untuk MCU LEDCAR/LEDLAMP dengan firmware `mayarota(3).ino`. `applicationId` adalah `com.hsjaya.led`, sehingga dapat dipasang berdampingan dengan aplikasi LEDCAR lama. UI disimpan sebagai HTML/CSS/JavaScript lokal **di dalam APK** dan komunikasi Bluetooth ditangani kode Android Java; aplikasi tidak memerlukan internet untuk mengontrol lampu.

## Tampilan

- Beranda mengikuti gambar referensi: logo RGB HYBRID, tombol menu tiga garis, roda pemilih warna besar, tombol daya, RGB, penggeser brightness/speed, enam preset, dan enam slot simpan warna.
- Menu samping membuka Mode Welcome, Standby, Sein, Rem, Mundur, Auto, 210 Mode, dan Setelan.
- Pilihan mode berupa lingkaran neon. Geser lingkaran atau deret angka di bawahnya secara horizontal; angka tengah menjadi pilihan aktif. Tombol **SIMPAN** mengirim ulang pilihan ke MCU.
- Kartu LED 1–4/ALL tersedia. Firmware hanya menyediakan pilihan kanal terpisah untuk 210 Mode dan RGB; Welcome/Sein/Rem berlaku untuk semua LED.
- Semua ukuran menggunakan tata letak responsif untuk layar ponsel, dapat digulir secara vertikal, dan memiliki safe area untuk status/navigation bar Android.

## Perintah firmware

BLE: service `FFE0`, characteristic `FFE1`. Paket 9 byte dimulai `7B`, diakhiri `BF`, kanal di byte 7. Kanal LED 1=`01`, LED 2=`02`, LED 3=`04`, LED 4=`05`, ALL=`03`.

| Fitur | Perintah |
| --- | --- |
| Brightness, speed, ON/OFF, RGB | `01`, `02`, `04`, `07` |
| LED count, 210 Mode, AUTO | `05`, `03` 1–210, `03 FF` |
| Welcome, Sein, Rem | `18` 0–50, `19` 0–10, `1A` 0–10 |
| Speed/brightness Rem, kunci modul, subarea | `02`/`01` dengan byte 3=`04`, `16`, `14` |

Mode Standby dan Mundur, kata sandi aplikasi, terjemahan English/Chinese, serta pilihan jeda Auto Custom belum memiliki dukungan pada firmware yang diberikan. Layarnya mengikuti referensi, tetapi pilihan tersebut hanya tersimpan di ponsel dan diberi penjelasan di UI. Jangan menganggapnya sebagai perubahan pada MCU. Saat kontak fisik/PIN7 LOW, firmware menolak perintah BLE selain Welcome.

## Unggah dan build APK di GitHub

Jika menerima paket `HS_JAYA_GITHUB_UPLOAD.zip`, ekstrak dahulu. Unggah **dua item** dari dalamnya ke akar repo `HS-JAYA`: arsip `HS_JAYA_ANDROID_PROJECT.zip` dan folder `.github` (berisi workflow `workflows/build-apk.yml`). GitHub akan menjalankan **Build HS JAYA APK** setelah commit. Buka tab **Actions** → run terbaru → unduh artefak **HS-JAYA-debug-APK**; di dalamnya terdapat `HS-JAYA.apk`. Jika GitHub menolak folder saat drag-and-drop, buat file baru `.github/workflows/build-apk.yml` melalui **Add file → Create new file**, salin isi berkas workflow dari paket, lalu unggah arsip proyek via **Add file → Upload files**.

Alternatif: unggah seluruh isi folder proyek Android ini sebagai file biasa bersama `.github`, lalu jalankan workflow. Proyek memakai Java 17, Android Gradle Plugin 8.6.1, Gradle 8.7 di CI, dan compile SDK 35. APK dari Actions adalah build debug untuk pengujian; rilis distribusi memerlukan proses penandatanganan tersendiri.
