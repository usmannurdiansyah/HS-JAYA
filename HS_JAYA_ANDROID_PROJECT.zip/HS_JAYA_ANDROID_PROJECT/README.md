# HS JAYA · RGB HYBRID

Aplikasi Android kedua untuk MCU LEDCAR/LEDLAMP dengan firmware `mayarota(4).ino`. `applicationId` adalah `com.hsjaya.led`, sehingga dapat dipasang berdampingan dengan aplikasi LEDCAR lama. UI disimpan sebagai HTML/CSS/JavaScript lokal **di dalam APK** dan komunikasi Bluetooth ditangani kode Android Java; aplikasi tidak memerlukan internet untuk mengontrol lampu.

## Tampilan

- Beranda mengikuti gambar referensi: logo RGB HYBRID, tombol tiga garis, roda pemilih warna besar, tombol daya, RGB, penggeser brightness/speed, enam preset api, dan enam slot simpan warna.
- Tombol tiga garis membuka **halaman pengaturan penuh** seperti referensi: Device & Connection; Mode Wellcome, Standby, Sein, Rem, Mundur, Auto; About; Password; Wallpaper; Bahasa. Pilihan 210 Mode tersedia setelah menggulir ke bawah. Ketuk Device & Connection untuk mencari modul BLE dan melihat status koneksi.
- Pilihan mode berupa lingkaran neon. Geser lingkaran atau deret angka di bawahnya secara horizontal; angka tengah menjadi pilihan aktif. Tombol **SIMPAN** mengirim ulang pilihan ke MCU.
- Kartu LED 1–4/ALL tersedia. Firmware hanya menyediakan pilihan kanal terpisah untuk 210 Mode dan RGB; Welcome/Sein/Rem berlaku untuk semua LED.
- Semua ukuran menggunakan tata letak responsif untuk layar ponsel, dapat digulir secara vertikal, dan memiliki safe area untuk status/navigation bar Android.

## Perintah firmware

BLE: service `FFE0`, characteristic `FFE1`. Paket 9 byte dimulai `7B`, diakhiri `BF`, kanal di byte 7. Kanal LED 1=`01`, LED 2=`02`, LED 3=`04`, LED 4=`05`, ALL=`03`.

Ketuk **Device & Connection → CARI & HUBUNGKAN**, izinkan *Perangkat di sekitar* dan *Lokasi*, lalu pilih `★ LEDCAR-02-9931`. Hasil scan muncul langsung; bila nama tidak terlihat, daftar juga memuat perangkat BLE lain untuk pemeriksaan. Jika aplikasi LEDCAR lama sedang terhubung, putuskan dulu koneksinya karena modul mungkin tidak beriklan selama terhubung. Untuk Android tertentu, hidupkan juga layanan Lokasi di ponsel. Status kegagalan scan/GATT muncul pada halaman koneksi. Versi Android 1.1.1 (`versionCode` 3) dipasang sebagai pembaruan dari versi sebelumnya.

| Fitur | Perintah |
| --- | --- |
| Brightness, speed, ON/OFF, RGB | `01`, `02`, `04`, `07` |
| LED count, 210 Mode, AUTO | `05`, `03` 1–210, `03 FF` |
| Welcome, Sein, Rem | `18` 0–50, `19` 0–10, `1A` 0–10 |
| Speed/brightness Rem, kunci modul, subarea | `02`/`01` dengan byte 3=`04`, `16`, `14` |

Mode Standby dan Mundur, kata sandi aplikasi, wallpaper khusus, terjemahan English/Chinese, serta pilihan jeda Auto Custom belum memiliki dukungan pada firmware yang diberikan. Fitur mode yang belum didukung hanya tersimpan di ponsel dan diberi penjelasan di UI. Jangan menganggapnya sebagai perubahan pada MCU. Saat kontak fisik/PIN7 LOW, firmware menolak perintah BLE selain Welcome. Tahap revisi ini memprioritaskan **beranda, koneksi, dan halaman tiga garis**; layar mode lain masih menunggu pencocokan gambar bersama pengguna.

## Unggah dan build APK di GitHub

Repo `usmannurdiansyah/HS-JAYA` sudah memiliki workflow `.github/workflows/main.yml`. Untuk revisi ini, unggah `HS_JAYA_ANDROID_PROJECT.zip` ke **akar repo** menggantikan arsip dengan nama yang sama; lalu commit. Workflow **Build HS JAYA APK** akan berjalan pada push ke `main`. Setelah berhasil, buka **Actions** → run terbaru → unduh artefak APK dan pasang `HS-JAYA.apk` di atas versi lama.

Alternatif: unggah seluruh isi folder proyek Android ini sebagai file biasa bersama `.github`, lalu jalankan workflow. Proyek memakai Java 17, Android Gradle Plugin 8.6.1, Gradle 8.7 di CI, dan compile SDK 35. APK dari Actions adalah build debug untuk pengujian; rilis distribusi memerlukan proses penandatanganan tersendiri.


## Fix 1.1.1

- Header ponsel diberi jarak atas dan target sentuh lebih besar agar tombol menu/setelan tidak terlalu menempel status bar.
- Tombol ON/OFF tidak lagi memakai karakter Unicode; ikon daya digambar dengan CSS agar tidak berubah menjadi tanda X/kotak pada font WebView tertentu.
- Ukuran roda warna dan margin horizontal dibuat lebih adaptif pada layar sempit.
